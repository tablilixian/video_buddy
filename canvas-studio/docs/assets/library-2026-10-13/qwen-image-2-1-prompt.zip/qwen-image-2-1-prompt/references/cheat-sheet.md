# Qwen-Image-2.1 提示词速查表

> 本表是检索加速器，**不是权威**。冲突时以 `system-prompt-t2i.md` / `system-prompt-edit.md` 原文为准。

## 一、画幅决策

### T2I 默认比例（Step 2）

| 情形 | 比例 |
|---|---|
| 横向（通用默认） | `3:2` |
| 纵向（通用默认） | `2:3` |
| 方形徽章 / 图标 / 专辑封面 / 单体居中标识 | `1:1` |
| 宽银幕 / 演示场面 | `16:9` |
| 手机屏 / 竖长条幅 | `1:2` 或 `9:16` |

`3:4` `2:1` `21:9` `4:3` `9:21` `4:5` `3:1` `5:4` `1:3` 存在，但仅在主体或用户明确要求时用。

### Edit 描述词 → 比例映射

| 用户说法 | 比例 |
|---|---|
| 正方形 / square / 头像 / avatar / 专辑封面 | `1:1` |
| 横版 / landscape / 电脑壁纸 / 视频封面 / PPT / 幻灯片 | `16:9` |
| 竖版 / portrait / 手机壁纸 / Instagram story / Reels / 短视频封面 | `9:16` |
| 手机全面屏 / iPhone 屏幕 | `18:39` |
| 安卓全面屏 | `9:20` |
| 超宽 / ultrawide / 带鱼屏 | `7:3` |
| 电影画面 / cinematic / 宽银幕 / cinemascope | `21:9` |
| 海报 / poster | `2:3` |
| 证件照 / ID photo / 小红书 | `3:4` |
| iPad / 平板屏幕 | `4:3` |
| 全景图 / panorama | `2:1` |
| 名片 | `9:5` |
| A4 | `5:7`（竖）/ `7:5`（横） |
| 1080p / 720p | `16:9` |

`2K` `4K` `8K` **只是质量词，不是比例线索**；编辑契约规定输出一律按 2K 级处理。给出精确像素（`1920x1080`）时化成最简整数比。

### 多图：先定画布，再定 `ratio_follow`

| 编辑类型 | 画布 = 谁 | `ratio_follow` |
|---|---|---|
| 合成（把 A 放进 B 的场景） | **场景图** | `<image场景号>` |
| 换脸 / 换头 | **身体图** | `<image身体号>` |
| 换衣服 / 换装 | **人物图** | `<image人物号>` |
| 风格迁移 | **内容图**（不是风格参考图） | `<image内容号>` |
| 换背景 | **前景主体图** | `<image主体号>` |
| 局部物体替换 | **被编辑的原图** | `<image原图号>` |
| 合影 / 合照 / 让他们 X（无画布） | 无 | `""`，改按场景选 `wh_ratio` |

无画布场景的 `wh_ratio`：合影 `3:2`｜写真 `2:3`｜海报 `2:3`｜电脑壁纸 `16:9`｜手机壁纸 `9:16`｜无方向线索 → 跟最后一张输入图。

### 单图例外

单图编辑默认 `ratio_follow = "<image1>"`。**例外**：单图场景生成（"拍一套写真""cosplay 成 X""穿越到古代"）不跟原图比，按写真 `2:3`｜全身场景 `3:4`｜横景 `3:2` 选 `wh_ratio`。

### 扩图（未指定目标比例时按方向推断）

| 方向 | 变化 | 例（1:1 输入） |
|---|---|---|
| 只向右 / 只向左 | 变宽 | `3:2` |
| 左右都扩 | 明显变宽 | `16:9` 或 `2:1` |
| 只向下 / 只向上 | 变高 | `2:3` |
| 上下都扩 | 明显变高 | `9:16` |
| 四周都扩 | **保持原比例** | 不变 |

经验值：扩展面积 ≈ 原图 30%–50%。**扩图必须在指令里明确写成 outpainting。**

### 全景 / 三视图

全景：标准 `2:1`｜超宽 `3:1`｜360°/VR `2:1`。
三视图：不套固定值，按「单格比例 × 列数 : 单格比例 × 行数」自适应——站立人三视图整体 `1:1`（**不要**拉成 `3:1`，会把竖版单格压扁）；汽车三视图 `3:1` 或 `9:2`；2×2 或 3×3 方形格 → `1:1`。

## 二、输出字段规则

| 字段 | 规则 |
|---|---|
| `rewritten_prompt` | 单段落、**无换行**、无省略号、无截断。图内可见文字用 `""` 包裹，非渲染的叙述不引号。**禁止出现任何比例 / 分辨率 / 像素数。** 肯定式表达。 |
| `wh_ratio` | `"W:H"` 格式；跟输入图时置 `""` |
| `ratio_follow` | `"<imageN>"` 格式；已给 `wh_ratio` 时置 `""` |

互斥：`wh_ratio` 有值 → `ratio_follow` 必为 `""`；反之亦然。

JSON 之外**不得有任何文字**——无问候、无解释、无 Markdown 围栏。

### 校验器的判定约定（校 `scripts/validate_prompt.py`）

- **直双引号内是"要渲染进图的文字"，属画面内容，不算画幅元数据。** 因此比例、像素、`4K` 这类写法出现在引号内只给 `WARN`（可能是规格标签、屏幕读数、徽标），出现在**正文散文**里才给 `ERROR`。质量粉饰词同理。
- **写产品规格表时的数字技巧**：尺寸写成 **cm 级两位数**（`18 × 20 × 8 cm`）不会撞上像素检测；写成 **mm 级三位数配 ×**（`180 × 200 mm`）会被误判成像素尺寸，需注意或改写。频率写成 `40 kHz` 安全，但要避免 `2K/4K/8K` 连写。
- 引号内的字符串还会被查**中英混排**——除非用户明确要双语，否则每条必须单语。**但标准化单位与专有名词自动豁免**（`mm` `Hz` `kHz` `dB` `mW` `g` `cm` `Ω` `USB-C` `LDAC` `AAC` `SBC` `Bluetooth` 等），所以 `阻抗 32Ω`、`编解码 LDAC/AAC/SBC` 这类是合法的，不算混排。真正的混排长这样：`参考级头戴式耳机 Reference Headphones`。

### 图内文字用中文时的四条硬约束

T2I 契约下**描述散文永远英文，只有引号内文字可以是中文**（Edit 契约则跟随指令语言——两套规则别串）。

| 项 | 处理 |
|---|---|
| 大小写 | 中文没有大小写，`upper-case` / `capital` 是无效指令，必须删掉 |
| 字体 | 用 `Chinese sans-serif face`（黑体）。宋体偏典籍气，与"科学/精密"调性不合 |
| 行距 | **必须显式要留白**：`set with generous line spacing and never crowd one another`。方块字视觉密度高于拉丁字母，行距不足直接糊成一片 |
| 条目数 | **中文条目数约为英文的 2/3**。同样像素高度下汉字笔画更早糊，22 条英文 ≈ 14 条中文 |
| 字号下限 | 拉丁字母有上下伸部、小字号仍可辨；汉字是满格方块，同尺寸下更容易糊。宁可少排几条，不要压字号 |

## 三、PE 权重采样参数（自建脚本调用 PE 时照抄）

| 参数 | T2I | Edit |
|---|---|---|
| temperature | 1.0 | 1.0 |
| top_p | 0.95 | 0.95 |
| top_k | 20 | 20 |
| min_p | 0 | 0 |
| **presence_penalty** | **1.5** | **0** |
| max_new_tokens | 16256 | 24000 |
| thinking | on（必开） | on（必开） |

`presence_penalty` 两个值**不可互换**：T2I 用它防长输出自我重复，Edit 不要。错了不会报错，只会静默改变采样分布。
`--seed`：离线 vLLM 批处理可复现；server 模式同 seed 也**不可复现**（batch 组成会变）。

**省 token 技巧**：在 system prompt 末尾追加 `Immediate Final Output` 强制直出 JSON 并关掉 thinking，约 500 token 出结果（默认烧 5000–6000）。

## 四、词汇表

- **风格**：realistic, photorealistic, minimalist, flat-vector, cinematic, watercolour, isometric, editorial, hand-drawn, 3D-rendered, retro
- **颜色修饰**（几乎不用裸色）：deep navy, muted olive, pale cream, warm terracotta, soft dusty rose, blue-grey, off-white, charcoal, brownish-green。**有 hex 才用 hex。**
- **材质**：brushed metal, matte plastic, glossy ceramic, coarse linen, weathered wood, frosted glass, grain, scuffs, condensation, visible brush strokes, paper fibre
- **光照**：soft diffused daylight from a window on the left / hard overhead studio light / warm low sun / flat even ambient light for a diagram
- **摄影与设计**：shallow depth of field, bokeh, backlit, close-up, negative space, grid, drop shadow
- **结尾句式**：`The overall composition ⟨is / uses / feels⟩ …` / `The overall mood …` / `The overall palette …`

## 五、出图侧参数与排坑（本地跑 DiT 时）

| 项 | 正确值 | 坑 |
|---|---|---|
| 采样步数 | **40** | ComfyUI 官方模板默认 **25 步**——这是"本地效果不如官方 demo"的第一大原因 |
| 分辨率 | 官方训练档 ~2 MP（2K，如 2048×2048 / 2752×1536） | 1 MP 出图偏肉；Diffusers 默认 `output_resolution=1024`，**必须显式传 width/height**。大幅超过 2048 级会破坏曝光 |
| CFG | ≈1（官方 40 步 / guidance 1） | **低于 1 不可用**；图内文字要更锐时可配小幅 CFG + 质量型负向提示词。用负向提示词需 `true_cfg_scale > 1` |
| 参考图 | 先缩放到合理尺寸再送入 | 过大的参考图会显著拖慢；官方 Edit 模板里 `image_1` 就是主 edit target 与画布锚点 |
| 多图一致性 | — | 约 **3 张参考图起**一致性开始下滑（早期单一评测，非基准）；10 张是容量上限不是目标——“一张参考图解决一个明确问题” |
| 全流程显存 | BF16 全量约 32–33 GB | 7B 只是视觉 DiT；另有 Qwen3-VL 8B 文本编码器（约 17.5 GB）+ RGBA VAE。16 GB 卡需 CPU offload；ComfyUI int8 组合约 14 GB |

**透明图 / RGBA 固定触发词**（不写就是 RGB）：

```text
This is an RGBA image with transparency. <主体描述>. The image has alpha channel and the background is transparent.
```

只写"白底"得到的是白底，不是透明。导出必须用 PNG（JPEG 载不了 alpha）。

## 六、T2I vs Edit 一眼对照

| | T2I | Edit |
|---|---|---|
| 输入 | 只有文字 | 1–10 张图 + 文字 |
| 输出文体 | **观察报告**（描述成品画面） | **操作指令**（从持有输入图的视角） |
| 时态人称 | 现在时第三人称，禁 `you`/`create` | 以操作动词开头 |
| 长度 | 约 20 句 / 400–500 词 | 按意图伸缩：局部改动克制，新场景构建到位 |
| 比例字段 | 只用 `wh_ratio` | `wh_ratio` 或 `ratio_follow` 二选一 |
| 语言 | 正文**永远英文**，图内文字保留原书写系统 | **(A)** 按指令语言；**(B)** 图内文字走三级优先 |
| 核心原则 | 八步顺序执行 | **Attribute Disentanglement**：只改点名属性并做到明确可辨，其余保持输入保真 |
| 两个对称失败 | — | **Leakage**（改了没点名的）/ **Under-editing**（改得太弱像原图） |
