# H3 运镜控制（Camera Motion）

把"镜头该怎样动"编译成 H3 能执行的指令，并保证模型真的照做。

---

## 何时用 / 不用

**用：** H3 视频提示词需要指定镜头运动；运镜失效诊断（说了环绕只给慢推、镜头完全不动、镜头乱抖、运镜压过主体）；需要把已有提示词补上运镜控制。

**不用：**

- **动作怎么编、交锋因果链、力量感与走位** → 走 `h3-flight-prompt`。
- **H3 字段规范、参考标签、Ref2VA 结构、对白写法** → 走 `h3-prompt-writing`。

**分工一句话**：本技能管的是**单个运镜怎么写才被模型执行**。

---

## 一、LoRA 事实表

| 项       | 值                                                  |
| ------- | -------------------------------------------------- |
| **触发词** | `camera motion` —— **必须放在 prompt 最开头**，它是激活运镜控制的开关 |
|         |                                                    |
|         |                                                    |
|         |                                                    |
|         |                                                    |
|         |                                                    |

**触发词是开关，不是修饰。** 不写 `camera motion`，运镜控制基本不生效——模型会退回它自己的默认镜头行为（通常是慢推或不动）。

---

## 二、提示词结构：六段公式

**训练素材的标注格式，也是本 LoRA 最匹配的写法：**

```
camera motion, [主体], [场景], [运镜描述], [光线/风格], [画质]
```

| 段           | 内容             | 示例                                                                        |
| ----------- | -------------- | ------------------------------------------------------------------------- |
| 0 **触发词**   | 固定，必须在最前       | `camera motion,`                                                          |
| 1 **主体**    | 谁 / 什么         | `two martial artists dueling with a straight jian and a folding fan`      |
| 2 **场景**    | 在哪             | `rain-damp stone courtyard of a temple at first light`                    |
| 3 **运镜**    | 镜头怎么动 ← **核心** | `dynamic handheld tracking shot with slight push-in following the action` |
| 4 **光线/风格** | 影调             | `cinematic natural lighting, damp reflections`                            |
| 5 **画质**    | 收尾             | `4k, high quality`                                                        |

**第 3 段决定成败。** 其余四段可以换，运镜短语不能糊。

**完整范式示例：**

```
camera motion, two martial artists dueling with a straight jian and a closed
iron-boned folding fan, rain-damp stone courtyard of a temple at first light,
dynamic handheld tracking shot with slight push-in following the action,
cinematic natural lighting with damp reflections, 4k, high quality
```

---

## 三、9 类运镜：稳定性评级与推荐短语

评级来自训练数据覆盖度（★★★ 最稳 → ★☆☆ 最弱）：

| 运镜                  | 评级         | 推荐短语                                          |
| ------------------- | ---------- | --------------------------------------------- |
| **推近** Push-in      | ★★★ 最稳     | `slow push-in` · `dolly in` · `push in`       |
| **拉远** Pull-back    | ★★★ 最稳     | `pull-back` · `dolly out`                     |
| **手持跟拍** Handheld   | ★★★ 最稳     | `handheld tracking shot` · `dynamic handheld` |
| **环绕** Orbit        | ★★☆ 稳      | `slow orbit` · `orbit around`                 |
| **航拍** Aerial       | ★★☆ 稳      | `aerial drone shot` · `flyover`               |
| **升降** Crane / Tilt | ★★☆ 稳      | `crane reveal` · `tilt up` / `tilt down`      |
| **推拉结合** Push+Pull  | ★★☆ 稳      | `push-in then pull-back`                      |
| **微距/特写** Close-up  | ★★☆ 稳      | `close-up` · `macro` · `extreme close-up`     |
| **摇镜** Pan          | ★☆☆ **较弱** | `pan left` / `pan right` —— **样本少，建议叠加其他运镜词** |

**摇镜是唯一需要特别处理的弱项**：单独写 `pan left` 容易不生效，叠一个主运镜更稳，例如  
`slow push-in with slight pan-right`、`gimbal glide with subtle pan right`。

---

## 四、强度与方向控制

| 需求       | 写法                                                                                                                                                            |
| -------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **更舒缓**  | 加 `slow`：`slow push-in` · `slow orbit` · `slow lateral tracking shot`                                                                                         |
| **更强烈**  | 加 `dynamic` / `aggressive`：`dynamic handheld` · `aggressive push-in` · `dramatic pull-back`                                                                   |
| **指定方向** | 加方向：`push-in from left` · `orbit right` · `pan left` · `orbit around the pair from left to right`                                                             |
| **复合运镜** | 用 `combined with` / `then` / `transitioning to`：`slow pull-back combined with gentle orbit` · `slow push-in to medium shot transitioning to slight pull-back` |

**复合运镜不是"多种运镜齐上"**（那在动作场面里必崩），而是**时间上有先后的一段连续运动**——  
`push-in then pull-back` 是一个镜头内的两拍，不是两个方向的力同时作用。

### ⚠️ 速度档的外推风险：词库偏向 slow

词库里的运镜条目**明显偏向 `slow`**——例如 6 条环绕条目**全部**是 `slow smooth orbit` / `slow orbiting camera` / `slow orbit`，**没有一条是快速环绕**。

所以「快速」属于**训练集外的外推档**，可能出现三种退化：

| 退化          | 表现                            |
| ----------- | ----------------------------- |
| **速度被拉回慢速** | 写了 `fast` 但模型给 `slow`（训练先验更强） |
| **半径漂移**    | 快速时镜头距离忽远忽近，主体忽大忽小            |
| **画面异常抖动**  | 高速下模型控制不住，出现非主观的抖             |

**对策（按优先级）：**

1. **用作者词族**：`dynamic` / `aggressive`（模型卡明确列为"更强烈"档），**不要自造 `fast` / `rapid` / `quick`**——作者用词在训练分布内
2. **强度提到 1.0**（明确档）对抗先验，但**不超过 1.2**
3. **锁半径**：`at a constant close radius` —— 快速环绕最忌距离变化，距离一飘就晕
4. **兜底**：退回 `slow orbit` + **缩短时长**。用更少的秒数换更强的速度感，比硬堆速度词稳得多
5. **不要叠词**：`fast dynamic aggressive orbit` 会互相干扰，主词只留一个

**快速运动时的额外纪律**：

| 项   | 做法                                                                      |
| --- | ----------------------------------------------------------------------- |
| 位移  | 人物位移要**降级**（整步 → 半步），把动感额度让给镜头                                          |
| 接触点 | 从"咬住"升级为**居中**：`keeping the point of contact centred in frame`          |
| 速度感 | 靠**背景掠过**表达：`letting the lantern and the steps streak past behind them` |
| 矛盾句 | 删掉"镜头只在撞击时震"之类的描写——镜头一直在动，那会互相矛盾并抑制运镜                                   |

---

## 五、两种替换方式（改场景 或 改运镜）

**① 换场景，保留运镜** —— 把 `[主体], [场景]` 换掉，**保留逗号后面的运镜短语**：

```
camera motion, [你的主体], [你的场景], slow push-in with subtle lateral tracking,
cinematic color grading, 4k, high quality
```

**② 换运镜，保留场景** —— 只替换运镜短语，其余不动：

```
camera motion, [主体], [场景], slow orbit around the subject, cinematic lighting, 4k
```

**优先从 55 条词库里直接取用**——那是训练素材原样标注，效果与训练数据最接近。  
库见 `references/prompt-library.md`。

---

## 六、与动作场面配合（重要）

### 触发词排序：`camera motion` 在前

同时挂 Camera Motion LoRA 与动作 LoRA（如 Wushu Action）时，两个触发词都要求"在最前面"。实战排序：

```
camera motion, [主体], [场景], [运镜描述], [光线/风格], [画质].
wushu_action, [动作描述……]
```

**`camera motion` 优先**，因为它是运镜的开关；`wushu_action` 跟在后面接动作描述。两者用句号分隔成两个语义块。

### 单镜头纪律

- **一个镜头只用一种主运镜。** 同时写环绕 + 推拉 + 手持抖动必崩——这是最常见的运镜翻车原因。
- 复合运镜必须**时间上有先后**（`then` / `transitioning to`），而不是空间上的多向叠加。
- **手持跟拍时**：镜头跟着主体走是"跟随"，不是"抖动"。要写清跟随对象与随动方式（`following the action` / `tracking sideways as they cross`）。
- **镜头太紧会削掉动作幅度**：大幅动作场面要写 `swings wide enough to keep both bodies in frame`，否则模型会压缩动作来适配画框。

### 运镜与走位叠加：动感额度是有限的

镜头运动和人物走位是**两个独立运动**，叠加会互相放大：

| 配置                 | 结果                |
| ------------------ | ----------------- |
| 镜头环绕 + 人物满场移动      | ❌ 双重运动失控，晕眩、看不清动作 |
| **镜头环绕 + 人物收在核心区** | ✅ 镜头提供动感，人物提供交锋   |

**判断方法：镜头自己在动时（环绕 / 航拍 / 升降），人物的活动半径要相应收窄；镜头跟随时（手持跟拍），人物可以满场跑。**

**为什么**：一部片子的"动感"总额度是有限的。镜头环绕已经吃掉大半，人物再满场跑就会失控。这不是取消走位——人物仍在换位、绕障碍、脚下移动，只是活动半径收窄。

### 环绕的三个固有代价与补偿

环绕（★★☆ 稳，库中写法 `slow smooth orbit around the pair from left to right`）天生适合两人对峙，但它有三个代价：

| 代价               | 补偿                                                                |
| ---------------- | ----------------------------------------------------------------- |
| **与走位叠加 = 双重运动** | 收窄人物活动范围到核心区                                                      |
| **会掩盖接触点**       | 写 `holding tight on the point where the weapons meet`（半径小，仍咬着接触点） |
| **屏幕左右关系会变**     | **限定为半圈弧**（`in one slow arc from left to right`），不绕整圈             |

**环绕幅度用半圈弧而不是整圈**：绕整圈会从主体背后经过，屏幕左右关系彻底翻转，观众会迷失。半圈弧既保留视角持续变化，又维持左右可读（结尾仍能声明 `Screen direction holds: A left, B right`）。

### 运镜要为主体的可读性服务

| 问题      | 改法                                          |
| ------- | ------------------------------------------- |
| 运镜压过主体  | 降低强度词（`aggressive` → `slow`），或换更稳的运镜（摇镜→推近） |
| 关键接触看不清 | 该镜改成固定机位或短促推近特写                             |
| 主体走出画框  | 写清跟随关系 + 留出画框余量                             |

---

## 七、常见失败与首选修正

| 症状                  | 原因               | 首选修正                                                             |
| ------------------- | ---------------- | ---------------------------------------------------------------- |
| **运镜完全没生效**         | 缺触发词，或没在句首       | 把 `camera motion` 放到 prompt 最前                                   |
| **说"环绕"却给慢推**       | 运镜短语太抽象          | 换成库里的完整短语：`slow smooth orbit around the pair from left to right` |
| **镜头乱抖**            | 多个运镜叠加           | 删到一个主运镜；手持跟拍写清"跟随"而非"抖动"                                         |
| **画面不稳、扭曲**         | LoRA 强度过高        | `strength_model` 降到 0.8；确认不超过 1.2                                |
| **`pan` 不生效**       | 摇镜是弱项            | 叠主运镜：`slow push-in with slight pan-right`                        |
| **环绕时画面晕眩、动作看不清**   | 环绕 + 走位双重运动      | 收窄人物活动范围到核心区；确认没写 `aggressive`                                   |
| **环绕后人物左右关系反了**     | 绕到了主体背后          | 改为半圈弧（`in one slow arc from left to right`），不绕整圈                 |
| **环绕时接触点看不清**       | 环绕掩盖了相交位置        | 补 `holding tight on the point where the weapons meet`            |
| **写了快速却出慢速**        | 词库只有 slow，训练先验更强 | 用作者词族 `dynamic` / `aggressive`；强度提到 1.0                          |
| **镜头距离忽远忽近、主体忽大忽小** | 没锁定半径            | 补 `at a constant close radius`                                   |
| **运镜中途变向、无逻辑**      | 复合运镜没写先后         | 用 `then` / `transitioning to` 明确时间顺序                             |
| **主体动作被压缩**         | 镜头太紧             | 补 `swings wide enough to keep both bodies in frame`              |
| **镜头与动作脱节**（人动镜头不动） | 只写了运镜类型，没写跟随关系   | 补 `following the action` / `tracking sideways as they cross`     |

---

## 参考文件

| 文件                                | 内容                                                                                         |
| --------------------------------- | ------------------------------------------------------------------------------------------ |
| `references/prompt-library.md`    | **55 条训练素材原样提示词**，按 9 类运镜组织（推近 12 / 拉远 6 / 推拉 4 / 环绕 6 / 跟拍 8 / 航拍 8 / 升降 4 / 摇镜 3 / 微距 4） |
| `references/motion-vocabulary.md` | 运镜术语中英对照、三维度表达法（类型/幅度/速度）、复合运镜句式                                                           |

---

## 相关技能

| 技能                  | 管什么                                    |
| ------------------- | -------------------------------------- |
| `h3-flight-prompt`  | 动作怎么编：交锋因果链、力量感与走位、招式连续与变招爆发、动作 LoRA 栈 |
| `h3-prompt-writing` | H3 字段规范、参考标签、Ref2VA 六段结构、对白写法          |
