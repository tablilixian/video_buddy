# 招式连续与变招爆发

**核心：一招被破，破法直接成为下一招的起势——所以没有"收回护架"这个动作。**

这是「无收招」和「有招式」能同时成立的原因：真正的连招（连环）就是招招相扣、以破为进。**上一招的收势就是下一招的起势。**

---

## 一、无收招的三重机制

| 机制 | 写法 |
|---|---|
| **条款锁定** | 开头与末尾各写一次：`no reset, no recovery step, no pause, no dwell between an attack and its contact` |
| **接触即变招**（核心机制） | 每次接触只持续一帧，**接触的同一帧变招已启动**：`Every contact is a single-frame collision: the instant the weapons meet, both men are already committed to the next technique.` |
| **变招即接续** | `Each technique ends by becoming the start of the next -- there is no interval in which either man is not already committed to his following move.` |

**⚠️ 不要用「兵器咬合不脱离」来保证无收招。** 这曾是一个被验证有副作用的做法：

| 代价 | 说明 |
|---|---|
| **画面糊** | 两件兵器长时间压在一起，H3 容易把接触点渲染成融合/穿透的一团，看不清谁在做什么 |
| **节奏拖** | 僵持吃掉时间，5 秒里塞不进四轮 |
| **变招失去意义** | 一直咬着就不需要"变招"——**变招的前提是分开重新构架** |

**禁用携带"维持性"的动词**（一出现就会黏连）：

| 禁用（黏连） | 替换（点接触） |
|---|---|
| `stays in contact` · `never leaves` | `touch for a single frame` · `clear off each other` |
| `locks` · `clamps shut` · `binds` | `drives down onto` · `takes it head-on` |
| `presses`（持续义）· `grinds` · `scraping along` | 用一次性动作替代，或直接删除 |
| `bite together` · `holds the contact` | `meet` · `collide` · `on the next frame the weapons tear clear` |

**分离必须写在同一段里。** 只写接触不写分离，模型会让兵器黏住。每次接触后紧跟一句：
`The weapons clear off each other.` · `The weapons tear clear.` · `weapons and bodies always separate cleanly.`

---

## 二、力量感不靠僵持，靠接触那一帧的瞬间形变

**关键认识**：力量感来自**撞击瞬间的身体形变**，不来自"顶住多久"。身体变形是一瞬间的事（1–2 帧）——脊柱折下去、膝盖沉下去、肩膀耸起来，接触那一下全部发生。**不需要靠僵持体现力量**，僵持反而让画面变糊。

```
In that single frame both men fold into it: A's spine folds forward over the blade,
his rear knee sinking into the stone, chin driven up off line; B's arm is driven
back against his own chest, shoulders coming up around his ears, stance
compressing. Then the weapons clear and both are already moving.
```

**力量感在，黏连不在。** 身体形变词汇见 `references/full-body-force.md`。

---

## 三、变招不是"切换"，是"蓄—发"

```
切换（扁平）  接触 → 换一个招式 ──────────────→ 接触      平稳，无爆发
爆发（有力）  接触 → 全身聚集 → 末端爆发释放 → 接触      有蓄有发
                    ↑ 变招过程本身就是蓄力
```

**关键：蓄力必须由变招过程本身承担。** 不能写成"先变招、再起势、再打"——那会出现一个额外的准备动作，破坏零间隙。正确写法：

> `the change itself is the wind-up`（**变招本身就是起势**）
> 变招的运动过程 = 蓄力的过程；变招完成的那一刻 = 爆发的那一刻。

**三阶段：**

| 阶段 | 写什么 | 关键句式 |
|---|---|---|
| **Gather** 流动聚集 | 脚重排 → 胯先行 → 脊柱拧转 → 肩带臂 → 兵器换线 | `his hips turn over ahead of everything, spine winding through the rotation, shoulders carrying the blade across` |
| **Release** 爆发释放 | 末端以全力打出新招 | `the cleave erupts out of the turn at full power` · `he just lets it go` · `his whole mass arriving behind the edge` |
| **Impact** 碰撞 | 新招撞上，身体折身 | `the knock goes straight through both of them` |

**为什么两者必须连在一起**：单纯全身流动会显得**飘**（像舞蹈）；单纯爆发会显得**突然**（没有来处）。**身体在流动中攒势能、末端一次性放出**，观众才看到有重量、有来处的爆发。

**禁止把变招写成"平移"**：`swings into a different technique`（切换）太平；要 `gathers the turn ... then erupts out of it`。

---

## 三、大幅变招怎么写跨度

幅度**不靠形容词**（`big`、`large`），靠写出跨了多少：

| 小变招 | 大幅变招 |
|---|---|
| `point drops and rolls into a rising flick` | `blade swings from the straight thrust over into a **vertical downward cleave**` |
| `ribs turn over into a horizontal parry` | `sweeps the fan up into a **shoulder-height** parry, **stepping through into a new stance**` |
| `rolls the blade off the ribs` | `rips the blade **up from low** into a rising flick, **uncoiling upward off both legs**` |

**幅度公式：起点方位 → 终点方位（跨方向 + 跨高度）+ 身体怎么动 + 脚步怎么重排。**

只写终点，模型只会给你一个手腕动作。

**镜头必须退远**：`swings wide enough to keep both men's bodies in frame`。镜头太紧动作会出框，**模型会自行压缩动作幅度**——你写的大幅变招会被削掉。

---

## 四、「顿」不等于「停」，但「顿」也不等于「顶住」

加了顿挫会不会破坏连续性？**不冲突**——但顿挫要短，且不能变成僵持。

| | 动作的停止（破坏连续性） | 接触的顿挫（制造力量感） |
|---|---|---|
| 时长 | 一拍以上，人明显停住 | **1–2 帧**，最多不超过"一次重呼吸" |
| 期间状态 | 双方静止、复位、重新起势 | **双方仍在用力、仍在动**（脚下碾转、肩膀耸高、手臂颤抖） |
| 观感 | 回合制、假 | 对抗感、真 |

prompt 里的锁定句：

```
The hard stops last only a frame or two and never become a pause: both men are
already driving into the next technique while the impact is still travelling
through their arms.
```

**力量压在接触的那一帧里**（六细节）：兵器停住 · 后脚碾地半圈 · 肩膀耸高压上去 · 水从两人脚下挤出 · 双臂受力下颤抖 · 脊柱折下去。

> **注意不要写成"互顶不退的僵持"**。长僵持会带来黏连（见第一节）。正确做法是把这六细节压缩进**接触的 1–2 帧**，然后立刻分离变招——力量感来自**形变的瞬间强度**，不来自**顶住的时间长度**。

"持续一次重呼吸"是个好用的**时长上限单位**（约 1 秒）——注意是**上限**，用于描述最重的一次接触，不是每轮都要用满。

---

## 五、「同时」的表达方式

要写双方同刻发动/发力/变招时：

**✅ 用：** `in the same frame` · `in the same beat` · `at the same instant` · `in the same motion`
**❌ 弃用：** `as` · `while` · `then` —— 含顺序意味，会让模型退化成回合制

**核心句式（消除防守位）：**

```
The two weapons are on converging lines and neither man is covering -- both are attacking.
```

**但注意：不是所有轮次都要双方同攻。** 真实对抗有攻防交替，"一方攻、一方硬接"同样成立，只要**防守是硬碰**（见 `references/full-body-force.md` 第五节）。两种轮次可以交替：

| 轮型 | 结构 | 变招方式 |
|---|---|---|
| **对撞轮** | 双方同刻出招 → 兵器相撞 | 双方同刻变招 |
| **硬接轮** | 一方进攻 → 另一方迎上去硬吃 | 硬接方借力变招 |

---

## 六、一个技术真相：「同时」必须用碰撞来证明

**"同时发生"在视频里是不可见的**——观众看不见"同一帧"，只能看见结果。所以每一次"同刻出招、同刻发力"**必须由一个可见事件锚定——那个事件就是碰撞**。

模型处理"同时"会退化成两种失败：

| 失败形态 | 表现 | 对策 |
|---|---|---|
| **退化成先后** | 一人先动、另一个慢半拍，变回合制 | 把时间钉死（见第五节），弃用 `as`/`then` |
| **退化成各打各的** | 两人动作互不相关，像在打空气 | 每个"同时"后面**紧跟碰撞**，用碰撞焊住两条动作线 |

**判断标准：每一轮都有一声碰撞，同时性就成立；某一轮没有碰撞，那一轮一定散了。**

---

## 七、不要直接写「随机」

**`random` / `randomly` / `at random` 不要写进 prompt**：H3 是确定性生成，"随机"不是可执行指令，只会让输出**混乱**而非**意外**。制造"不可预测感"要用可执行替代：

| 想表达 | 不要写 | 要写 |
|---|---|---|
| 随机 | `randomly` | `not to the obvious technique` · `both go the way nobody expects` |
| 猜不到 | `unpredictably` | `neither man gets the technique he was bracing for` |
| 每次不同 | `every time differently` | **`each man attacking the exact line the other has just abandoned`** |

**最后一句是核心机制**：碰撞后 A 攻向 B 刚放弃的线，B 同时攻向 A 刚放弃的线——**两人招式方向互换**。比"随机"更精确、更可执行，效果就是"谁都没防到"。

---

## 八、招法形状：观众靠形状辨识招式

只写招式名，观众认不出来。**每一招都要补一句形态描写：**

| 招式 | 形状描写 |
|---|---|
| 中平剑直刺 | `blade level with his shoulder` |
| 撩剑 | `a low-to-high arc up the ribs` |
| 缠头裹脑 | `around the back of his neck in a full turn` |
| 扇骨锁剑 | `ribs and blade cross` |
| 扇面拍剑 | `the fan face coming down flat onto the flat of the blade` |

**没有形状描写，招法读不出来，就只剩两团兵器在撞。**

同时给每个招式配一个**该招独有的受力结果**（撞停 / 被压弯 / 被挑起 / 被压偏离线），这样招式之间的差异才可读。

---

## 九、排查表

| 症状 | 原因 | 改法 |
|---|---|---|
| 变招像"平移"，没爆发 | 缺"聚集→释放"结构 | 拆两段：先 `gathers the turn -- foot, hips, spine, shoulders`，再 `erupts out of the turn at full power` |
| 变招有爆发但来得突然、没来处 | 爆发前没有身体流动 | 补 Gather 段 |
| 变招像舞蹈、飘 | 只有流动没有释放 | 末端必须落成一次实招，且写 `at full power` |
| 变招还是小动作 | 只写了终点没写起点 | 补起点方位 + 跨高度 |
| 感觉像回合制 | 折身/相撞后重新站好了 | 保持折身进下一招；检查是否用了 `as`/`then` |
| 两人各打各的 | 同刻性没被锚定 | 每次"同时"后紧跟碰撞 |
| 看起来像固定套路 | 变招方向可预期 | 补 `each man attacking the exact line the other has just abandoned` |
| 招式看不清 | 缺招法形状 | 补形状描写 + 该招独有受力结果 |
| **兵器黏在一起分不开** | 出现了"维持性"动词 | 删 `stays in contact` / `locks` / `presses` / `grinds` / `bite together`，换 `touch for a single frame` / `clear off each other` |
| **只写接触没写分离** | 缺分离句 | 每次接触后紧跟 `The weapons clear off each other.` / `The weapons tear clear.` |
| **人物肢体黏连** | 只写了兵器分离，没写身体 | 补 `weapons and bodies always separate cleanly` |
| **接触后有空白拍** | 变招没绑在接触帧上 | 补 `on that same frame both are already gone from the contact` |
| **不黏连后力量感变弱** | 力量没压在接触帧里 | 把六细节集中写进接触的那一帧（见第二节） |
| **碰到就停、变回合制** | 分离后没立刻出新招 | 补 `the next technique always begins on the frame of contact` |
| **声音里有长时间金属摩擦** | 音效写了黏连 | 删 `grinding` / `scraping along`，改 `a short flat knock` + `air snapping as they clear apart` |
| 变招后肢体畸变 | 变招时没写脚步落点 | 每次变招配一个新步型 |
