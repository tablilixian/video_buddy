# NOTICE — 来源、许可与完整性

## 收录的官方文本

本技能的提示词契约来自 Qwen 官方开源仓库，**逐字复制、未作任何改写或删减**：

| 本地文件 | 上游路径 | 字节 | SHA-256 |
|---|---|---|---|
| `references/system-prompt-t2i.md` | `QwenLM/Qwen-Image-2.1` → `prompt_rewrite/prompts/system_prompt_t2i.txt` | 10045 | `a77c9a06c59b120741141d9514b95682bb8761d02bec49ca61def7b2b3d9fb99` |
| `references/system-prompt-edit.md` | `QwenLM/Qwen-Image-2.1` → `prompt_rewrite/prompts/system_prompt_edit.txt` | 18344 | `e378fea686a1431581ba4c654d332ae96adad633f144ae738ec8ce9c4fd66439` |

上游抓取时间：2026-09-25。文件首行标识：T2I 为 `# Image Prompt Rewriting Expert`；Edit 为 `# Edit Prompt Enhancer — General (v2, 精简版)`。

校验完整性：

```bash
sha256sum references/system-prompt-t2i.md references/system-prompt-edit.md
```

两个哈希与上表不一致即说明文本已被改动，请以官方仓库为准重新拉取。

## 许可

- 上述官方 prompt 文本的版权归 **Alibaba Qwen Team（杭州通义实验室）**。
- Qwen-Image-2.1 整体（含两个 prompt 改写模型 PE-T2I / PE-I2I）适用 **Qwen Research License Agreement**，发布日期 2026-09-20：**仅限非商业研究与评估用途**，商用需另行取得授权。这与早期 Qwen-Image 的 Apache-2.0 不同。
- 再分发与衍生模型需带许可、保留 `Built with Qwen` / `Improved using Qwen` 声明与版权行，且不得以 `Qwen` 作为衍生模型主名称。
- 本技能的其余内容（SKILL.md、cheat-sheet.md、validate_prompt.py）为本地整理产物，只做格式组织与路由，**不改变上述任何条款**。
- 本技能为非官方产物，与 Alibaba / Qwen 团队无关联、未获其背书。

## 生态参照（非依赖）

- `iamyoki/qwen-image-2.1-skill` — skills.sh 标准的独立实现，结构为单 `SKILL.md` + `t2i_rules.md` / `edit_rules.md` / `cheat_sheet.md`。本技能未复制其内容；差异在于本技能**逐字内嵌官方全文**而非重述要点。
- `vanche1212` / `fq393` 的 `ComfyUI-ZMG-Nodes` — ComfyUI 侧用通用模型复刻官方契约的实践，其 README 自述"27B 通用模型不等同于官方微调的 PE-I2I 权重"。
