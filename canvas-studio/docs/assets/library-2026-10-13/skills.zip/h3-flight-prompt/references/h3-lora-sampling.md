# H3 动作类 LoRA 栈与采样参数

**先分清责任：LoRA 决定"这些动作怎么表现"，提示词决定"他们怎么打"。** 单挂动作 LoRA 而提示词只写 `two people fighting`，依然产出"王八拳"。

---

## 一、动作场面 LoRA 栈全景

| 层 | 组件 | 触发词 | 强度 | 作用 |
|---|---|---|---|---|
| **动作本体** | Jojocodex **Wushu Action v7** | `wushu_action` | 0.5–1.0 | 拳腿棍法翻腾、身体力学 |
| **编排基座** | JOKER141 **Combat Base V2** | 无 / `prfight2` | 0.5–0.7 | 连续运动链、受击累积、格挡顺势变向 |
| **兵器** | JOKER141 **Weapon Combat** | — | 0.3–0.5 | 武器轨迹连续性、空间战斗 |
| **修复** | JOKER141 **Motion Continuity Repair** | `bunny_crisp_motion` | 单用 0.9 / 配武打 0.2–0.7 | 治无故变慢、缺过渡、轨迹跳变 |
| **物理** | Jojocodex **Spatial Physics** | 无 | 0.3–0.5 | 碰撞、堆叠、掉落、动量传递 |
| **运镜** | Jojocodex **Camera Motion** | `camera motion`（句首） | 0.8–1.0（>1.2 不稳） | 9 类运镜 + 55 条词库 |
| **加速** | LightX2V 8-step / VDN-H3 Turbo | — | 0.65–1.0 | 4–8 步出片 |

**运镜只用其一**：`Camera Motion` 与同作者的 `Yunjing`（触发词 `yunjing`，12 种运动）都训了运镜，**每个镜头只挂一个**。

---

## 二、关键组件细节

### Wushu Action v7（动作本体首选）

- 仓库：`huggingface.co/Jojocodex/wushu-action-v7-minimax-h3-fl2va-ref2va-lora`
- 训练：924 段精选武打片段（832×480 @ 24fps），**专业招式术语三段式打标**
- 底模：全量 int8-convrot DiT（**未剪枝**）+ bf16 Qwen3-VL
- **分区与文件配对**：FL2VA / Ref2VA 双版本；每区再给 **adaln / NO-ADALN** 两种文件
  → **adaln 版配 Full 底模；NO-ADALN 版配 Pruned 底模**。**FL2VA ≠ Ref2VA，不可互换**
- 强度：崩坏时降到 0.6–0.8；动作不够"武"升到 1.1
- **低步数（4 步）出片偏模糊，至少 8 步**
- 附带 `招式TAGS完整清单.md`（训练集全量招式标签，写提示词时优先从这里取词）

**旧版关系（常见坑）**：`Jojocodex/minimax-h3-wushu-action-lora` 里的 `KungFu_MiniMaxH3_LoRA_step4500`（触发词 `kungfu combat`）**不是 v7 的升级，是另一条训练线**。

| 触发词 | 管什么 | 词汇特征 |
|---|---|---|
| `wushu_action` | **身体**：重心转移、胯肩旋转、蹬地爆发、落地缓冲 | 招式 + 身体协调 + 发力 |
| `kungfu combat` | **场面**：尘土、动态模糊、竹林雾气、手持抖动、大摇臂 | 环境 + 镜头 + 风格质感 |

**步数高不等于版本新**，选哪个取决于"镜头的哪一半必须立住"。

### Combat Base V2（编排基座）

- 仓库：`huggingface.co/JOKER141/MiniMax-H3-Combat-Base-V2`（`H3_Combat_V2.safetensors`，155 MB）
- 触发词：**无触发词**（人体解剖最稳）→ `prfight2`（更强攻击性）→ `prfight2, prfin1`（重终结/特技受击）
  > 触发词有版本冲突：模型卡 Workflow 章节写 `prfight2`，社区转载写 `prfight1`。顺序：**先不加 → `prfight2` → 退回 `prfight1`**。`prslow1` 不自动出慢动作，必须同时在提示词里明写。
- **采样器强绑定**：`res_multistep + simple` 或 `euler + beta`。其他组合明显更糊更软
- 它做什么：摆脱"攻击→复位"回合制，改**连续物理链**（落空延续动量、**格挡自然顺势变向**、接触点脱离不黏连）；**受击累积**（躯干弯曲、护架变慢、移动受限会保留）；三阶段环境碰撞；1vMany 围攻调度
- 文戏收益（同 seed）：镜内动作量 +19.5%、Audio RMS +34.2%、边缘锐度 +22.4%
- **硬约束**：同镜有打斗+对白时，**必须先完整打完再说台词**（ACTION → DIALOGUE）

> **「格挡可自然顺势变向」是 H3 生态里唯一原生支持"防守后变招"的能力** —— 需要"硬防守 + 借力变招"时，这个 LoRA 不可替代。

### 长尾兵器（训练集外的武器）

Wushu Action v7 的 924 段素材覆盖**剑、刀、枪棍、鞭腿、贴山靠、擒拿**等，但**不含扇、双钩等长尾兵器**。这类兵器的形制保持全靠基模 + 提示词里的物理描述。

**按顺序处理（从最有效开始）：**

1. **明确写死形态**：`kept closed throughout`（**闭合扇形态唯一，最稳**）
2. **改 Ref2VA 版本 + 一张该兵器的手部参考图** —— 直接锁死形制，**这招最有效**
3. **写死数量**：`the fan keeps exactly five visible ribs`
4. **降低该角色的动作幅度**（转体半圈 → 四分之一），牺牲幅度换稳定
5. **降 Wushu 强度到 0.5**，把权重让给基模的理解能力
6. **降级换训练集覆盖的兵器**（短刀、双钩），代价是失去原本的味道

> 长尾兵器的风险会被**速度、撞击强度、动作幅度、走位**四者放大——每加一项，形制保持力就下降一档。

---

## 三、采样硬约束（不遵守必崩）

| 参数 | 值 |
|---|---|
| **CFG** | **固定 1.0**。H3 是 CFG 蒸馏模型，**>1 必出坏图** |
| **帧数** | **必须 17n+5**：22 / 39 / 56 / 73 / 90 / 107 / **124** / 175。124 帧 ≈ 5.17s |
| 分辨率 | 832×480（竖屏 480×832）/ 1344×768；32 的倍数 |
| fps | 24 |
| shift | 12/3（部分工作流用 3） |
| 步数 | 4 步会糊；Wushu v7 **≥8 步**；质量档 20–30 步 |
| **功能 LoRA 合计** | **≤2.0**（**Turbo 加速不计入**）。超了功能 LoRA 互相污染 |
| 二次采样 | 动作快时必须做：第一阶段跑动作，第二阶段用 3D Latent 节点放大收细节 |

**采样器冲突处理**：Wushu v7 官方推荐 `euler / simple`，Combat Base V2 强绑定 `res_multistep + simple` 或 `euler + beta`。
→ **挂 Combat Base V2 用 `euler / beta`；不挂用 `euler / simple`。**

**⚠️ 不要信网上模板的参数**：大量流传的"打斗/仙侠提示词模板"标注 `CFG 7-8`、`28-32 步`、`DPM++ 2M`，**对 H3 全是错的**。这类模板唯一可取的是"5–8 秒短镜 + 单一运镜 + 写清动作音效"三条。

---

## 四、可复用配方

**A. 动作验证档**（改完提示词先跑这个，不要一上来挂加速——加速会掩盖动作问题）

```
Wushu Action v7 (NO-ADALN 版，配 Pruned 底模)   0.6
Spatial Physics                                 0.3
euler / simple，20–25 步，CFG 1.0，124 帧 @ 24fps
```

**B. 生产档（三个变体，按本片最看重什么来选）**

```
【重量/受力优先】—— 需要力量感、受击反馈、硬防守
  Wushu Action v7          0.6
  Combat Base V2           0.6
  Weapon Combat            0.4
  Motion Continuity Repair 0.2
  Spatial Physics          0.2          合计 2.0

【攻防转换优先】—— 需要"硬接后大幅变招"
  Wushu Action v7          0.6
  Combat Base V2           0.7
  Weapon Combat            0.3
  Motion Continuity Repair 0.2
  Spatial Physics          0.2          合计 2.0

【走位/轨迹优先】—— 需要大量位移与移动中变招
  Wushu Action v7          0.6
  Combat Base V2           0.6
  Weapon Combat            0.3
  Motion Continuity Repair 0.3
  Spatial Physics          0.2          合计 2.0
  + LightX2V 8-step turbo  1.0（不计入）
```

**权重分配的判据：**

| 本片最缺什么 | 加谁 | 从哪挪 |
|---|---|---|
| 力量感 / 受击累积 | Combat Base V2 ↑ | Weapon Combat |
| 兵器接触不穿透、轨迹连续 | Weapon Combat ↑ | Motion Repair |
| 移动中的动作断链、轨迹跳变 | Motion Continuity Repair ↑ | Combat Base V2 |
| 环境反馈（撞墙、水花、砂砾） | Spatial Physics ↑ | 其他 |

---

## 五、分遍生产流程

**动作、特效、风格分遍做，每遍只改一个变量，崩了能定位。**

```
第一遍  出基础动作     Wushu v7 + Combat Base V2（+ Weapon Combat / Spatial Physics）
第二遍  补特效（如需） VFX Edit LoRA（触发词 vfx_edit:，强度 1.0）
第三遍  统一风格 + 收细节（Style Transfer / 锐化）
```

**一次生成"高速招式 + 复杂特效 + 多角色 + 大位移"必然崩**——误差累积。

**VFX Edit 使用要点**（`huggingface.co/Alissonerdx/Minimax-H3-ComfyUI`，2026-09 发布）：
- 它**是编辑型不是生成型**：必须先有基础片段，再用一句话加特效
- 提示词模式：**先说加什么，再列必须保持不变的东西**（身份/姿态/动作/服装/构图/光照/背景）
- **铁律：永远不要要求它保留你正要替换的那个区域**
- 源片段走 `MiniMaxH3AddGuide`（`frame_idx = 0`），**不要**放进 video-reference 槽位
- 已知局限：身份漂移、文字 logo 被改写、**长片段效果差**（按 5–8 秒分段）

---

## 六、时长纪律

**5 秒（124 帧）能塞下的动作上限是四轮交锋，每轮约 1.2 秒。**

| 诉求叠加数量 | 建议时长 |
|---|---|
| 单纯打到（无变招无走位） | 73 帧 ≈ 3s 可试 |
| 变招 + 受力 | 124 帧 ≈ 5.17s |
| 变招 + 受力 + 走位 + 爆发 | **124 帧，不要压缩** |

**为什么复杂诉求不能压时长**：

| 被压缩的要素 | 后果 |
|---|---|
| 大幅变招 | "聚集→释放"来不及呈现，**爆发感直接消失**，整劲退化成抖动 |
| 全身变招 | 步型来不及重排 → **肢体畸变** |
| 顶力段 | 那 1–2 帧的"顶住"被压没 → **刚建立的碰撞感消失** |
| 走位 | 位移变成"瞬移"，观众看不出人是怎么过去的 |
| 同刻性 | 模型来不及对齐两条动作线 → 退化成各打各的 |

**要更快，请提高 124 帧内的动作密度，不要缩时长。**

**慢动作的位置**：全片最多一次，**只给最重的那一次接触**（0.15–0.3s）。用慢镜做力量感是偷懒办法，且会让招法形状失真——**力量感来自受力可见，不是来自慢镜头**。
