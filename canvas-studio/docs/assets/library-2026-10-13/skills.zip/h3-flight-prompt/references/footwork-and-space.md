# 走位与空间连续性

**核心：位移必须由招式驱动，且镜头必须跟着人走。**

---

## 一、站桩的病根

为了让下半身不漂移，很容易把所有移动都写成**原地重排步型**：

```
re-plants into a stance      原地重排步型
holds his ground             守住地面
both feet planted wide       双脚站宽
```

漂移是防住了，代价是**两个人从头到尾站在同一小块地方打**——兵器在动、上身在动、脚下不动。**这就是站桩。**

**修法：把「落点」从「原地」改成「新位置」。**

```
原地重排（站桩）  his lead foot re-plants into a shorter stance
移动中的落点      his feet carry him forward two steps as the cleave lands
```

**位移由招式承载，不单独占时间**：不存在"先打完再走"或"先走再打"——劈砍的挥动本身就是位移。这样位移是"免费"的，5 秒里也能塞进大量移动。

| 招式 | 自然带出的位移 |
|---|---|
| 劈砍 | 前冲 |
| 撩剑 | 上步、重心上拔 |
| 横扫 | 转体移位 |
| 后撤反击 | 退中有打 |
| 转身反刺 | 整圈旋转位移 |
| 绕侧 | 弧线移动 |

---

## 二、一个必须分清的矛盾：「不退让」≠「不移动」

防守要求"不退让"时，容易写成钉在原地。**两者不矛盾：**

| 概念 | 含义 | 处理 |
|---|---|---|
| **不退让** | 不放弃对抗、不脱离接触、不躲到安全距离 | **保留** |
| **不移动** | 脚下钉在一个点上 | **删除**（这是站桩） |

**防守时的正确形态是横向移动、绕圈、斜切**——都在"不退让"范围内，但人是动的。被大力推时会有真后退，**但后退之后立刻侧切绕开重新找角度，不是站定**：

```
被压得后退 → 脚下立刻绕开 → 从新角度反打
```

这比"钉住不退"更像真实武打，也更有观赏性。

---

## 三、空间锚点：走位不漂移的关键

**在移动镜头里，如果场地没有任何可辨识的地标，模型会丢失空间关系——人物会看起来像在"漂浮"。**

**场景必须提供固定锚点。** 两种来源：

| 场景类型 | 锚点来源 | 代价 |
|---|---|---|
| **封闭空间**（窄巷、走廊、房间） | 墙、柱子、门框天然是锚点 | 但**锁死走位空间**——两人被夹住只能原地打 |
| **开阔空间**（庭院、广场、山道） | 必须人工造锚点 | 需要额外给地标 |

**开阔场景的锚点配置（推荐配置）：**

| 元素 | 作用 |
|---|---|
| 开阔铺地（青石、木板、沙地） | 走位空间 |
| **一根立物**（石灯柱、树、立柱）偏离画面中心 | 空间锚点：绕它转、被它分隔、从它后面转出来 |
| **边界或高度变化**（台阶、矮墙、水边） | 逼他们转向，而不是无限后退 |
| **大片积水 / 沙地 / 落叶** | 走位证据：轨迹被留下 |
| 单一顶光 | 光影随人移动扫过地面 |

**结尾帧必须重申锚点位置**，用来锁定整段的空间关系：
`The stone lantern is visible behind them and the puddle at the screen-left corner has been left well behind.`

---

## 四、走位怎么写"看得见"

**① 位移量化。** 不写 `moves`，写具体量：
`two hard driving steps`（两步硬抢）· `a pace and a half`（一步半）· `a full pace further left`（再向左一整步）· `a full body width`（一个身宽）· `three quick steps`（三步快移）

**② 招式带位移**（见第一节表格）。句式：
`the swing itself takes him a full pace further left`（挥动本身把他再带左一整步）

**③ 用背景参照物证明移动** —— 最有效的一招，**观众看见背景在变就知道人在动**：

```
both are standing where the other started
the two of them come out on the opposite side of the lantern from where they went in
walking through the ground A has just given up
```

**④ 水花 / 衣料拖出轨迹：** `their splashes trailing behind them` · `water thrown off their feet in trails behind them`

**⑤ 镜头必须跟着走。**

```
The camera moves with them across the courtyard -- backing off as they close,
tracking sideways as they cross and circle, swinging around the lantern with them.
```

> **这条是隐性的关键**：镜头钉在原地时，人一走就出框，**模型会自动把人拉回来**——这就是隐性站桩的成因。

---

## 五、走位带来的三个风险

**① 空间漂移** → 场景必须有固定锚点，且结尾帧重申锚点位置。

**② 走位与变招抢时间** → 位移由招式承载，不单独占时间（见第一节）。

**③ 接触点漂移**（两人都在移动时兵器对不上）→ 碰撞前写清双方是"相向移动"还是"同向移动"：

| 差 | 好 |
|---|---|
| `their weapons meet` | `they collide at chest height **still travelling into each other**` |

后者给出了**速度方向**，接触点因此可预测。

---

## 六、走位轨迹的设计

**位移不能随机乱走，必须有动力来源。** 最自然的动力是**距离争夺**：

| 角色类型 | 想要的距离 | 自然走位 |
|---|---|---|
| 长兵器 / 剑 | 保持一个兵器长 | 被逼近时**后退、侧切**拉开 |
| 短兵器 / 徒手 | 贴身内侧 | **抢步压进**，对方退就追 |

**两人的走位方向天然相反**，形成一圈一圈的位移，不需要额外设计。

**四种可复用的走位弧线：**

| 弧线 | 写法 |
|---|---|
| **对冲换位** | 双方相向冲来 → 碰撞 → 各自斜向错开，**互换左右** |
| **追退环绕** | 一方抢步压进，一方退中反击，一路打到某个地标旁 |
| **对撞换位** | 移动中对撞 → 顶力 → 同时反向爆发，**各自走进对方刚让出的地面** |
| **绕侧追架** | 一方绕到另一方侧外，另一方转身追架（**转身本身是位移**） |

**终点状态要可读**：`both are standing where the other started`（两人站在对方原来的位置）—— 这种句子让观众立刻确认"他们真的换位了"。

---

## 七、排查表

| 症状 | 原因 | 改法 |
|---|---|---|
| 人基本站在原地打 | 走位台词缺失 | 每个招式补一个步数：`carries him forward two steps` |
| 晃动但没走远 | 只写"动"没写方向和距离 | 补方向 + 量化：`falls back a pace and a half, angling off to his own right` |
| 看不出移动 | 没有背景参照 | 补锚点参照：`come out on the opposite side of the lantern` |
| 人走过去但像在"飘" | 缺空间锚点 | 场景加固定地标（立物 / 台阶 / 水坑），结尾帧重申其位置 |
| 动作被镜头拉回原地 | 镜头没跟着走 | 补 `The camera moves with them across the ...` |
| 兵器对不上 | 没写移动方向 | 补 `still travelling into each other` |
| 走位后画面糊成一片 | 位移过大没锚定 | 缩小单次位移量，多加地标参照 |
| 力量感被走位冲淡 | 只顾走位丢了折身 | 走位句与折身句必须同时在场：`fold into it while still moving` |
| 防守变成钉在原地 | 把"不退让"写成了"不移动" | 改成横向移动、绕圈、斜切 |
