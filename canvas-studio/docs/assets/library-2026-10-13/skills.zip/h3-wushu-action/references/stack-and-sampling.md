# wushu_action 的 LoRA 栈与配方

> **本文件只写"以 wushu_action 为主角"的配置。**
> 完整的动作 LoRA 栈全景、每个组件的训练细节、分遍流程与时长纪律，
> 见 `h3-flight-prompt/references/h3-lora-sampling.md` —— 两份不要各写一份，避免漂移。

---

## 一、栈位（wushu_action 在哪一层）

| 层 | 组件 | 触发词 | 强度 | 作用 |
|---|---|---|---|---|
| **动作本体** | **本技能：Wushu Action（v5 / v7）** | `wushu_action` | **v5: 0.5 · v7: 0.8–1.0** | 身体力学：重心转移、胯肩旋转、蹬地爆发、落地缓冲 |
| 编排基座 | JOKER141 Combat Base V2 | 无 / `prfight2` | 0.5–0.7 | 连续运动链、受击累积、格挡顺势变向 |
| 兵器 | JOKER141 Weapon Combat | — | 0.3–0.5 | 兵器轨迹连续性 |
| 修复 | Motion Continuity Repair | `bunny_crisp_motion` | 0.2–0.7 | 治无故变慢、轨迹跳变 |
| 物理 | Jojocodex Spatial Physics | 无 | 0.3–0.5 | 碰撞、动量传递、环境反馈 |
| 运镜 | Jojocodex Camera Motion | `camera motion`（句首） | 0.8–1.0 | 9 类运镜 + 55 条词库 |
| 加速 | LightX2V 8-step / VDN-H3 Turbo | — | 0.65–1.0 | 4–8 步出片 |

> **`wushu_action` 与 `spatial-physics` 是官方点名的一对**：仓库 A 的模型卡原话是
> 「Wushu-Action-LoRA **0.5 的强度**搭配 **0.3 强度 spatial-physics-lora**，打斗的效果会更好」。
> 这是最省事的最小可用组合，先跑这个再往上加。

**运镜只用其一**：Camera Motion 与同作者的 `Yunjing`（触发词 `yunjing`）都训了运镜，每镜只挂一个。

---

## 二、三套配方（以 wushu_action 打底）

```text
【最小可用 —— 先跑这个验证动作】
  Wushu Action (仓库 A v5)        0.5
  Spatial Physics                 0.3
  euler / simple，25 步，CFG 1.0，124 帧 @ 24fps

【重量/受力优先 —— 需要力量感、受击反馈、硬防守】
  Wushu Action                    0.6
  Combat Base V2                  0.6
  Weapon Combat                   0.4
  Motion Continuity Repair        0.2
  Spatial Physics                 0.2          合计 2.0

【攻防转换优先 —— 需要"硬接后大幅变招"】
  Wushu Action                    0.6
  Combat Base V2                  0.7
  Weapon Combat                   0.3
  Motion Continuity Repair        0.2
  Spatial Physics                 0.2          合计 2.0
```

**权重挪动判据**：

| 本片最缺什么 | 加谁 | 从哪挪 |
|---|---|---|
| 力量感 / 受击累积 | Combat Base V2 ↑ | Weapon Combat |
| 兵器接触不穿透、轨迹连续 | Weapon Combat ↑ | Motion Repair |
| 移动中断链、轨迹跳变 | Motion Continuity Repair ↑ | Combat Base V2 |
| 环境反馈（撞墙、水花、砂砾） | Spatial Physics ↑ | 其他 |

---

## 三、采样硬约束（摘录，完整版见 flight-prompt）

| 参数 | 值 |
|---|---|
| **CFG** | **1.0**（>1 必崩） |
| 采样器 | `euler + simple`（Wushu 官方）；挂 Combat Base V2 → `euler + beta` 或 `res_multistep + simple` |
| 步数 | **≥8 步**；质量档 25 步；4 步会糊 |
| 帧数 | **17n+5**：22 / 39 / 56 / 73 / 90 / 107 / 124 / 175 |
| 分辨率 | 832×480（竖 480×832）/ 1344×768，32 的倍数 |
| fps | 24 |
| 功能 LoRA 合计 | **≤2.0**（Turbo 不计入） |

**加速 LoRA 会掩盖动作问题** —— 提示词改完后先用不带加速的档验证，再上 4/8 步。

---

## 四、时长纪律（照抄 flight-prompt 的结论，别自己压）

**124 帧（5.17s）能塞下的动作上限是四轮交锋，每轮约 1.2 秒。**

| 诉求叠加 | 建议时长 |
|---|---|
| 单纯打到 | 73 帧 ≈ 3s 可试 |
| 变招 + 受力 | 124 帧 |
| 变招 + 受力 + 走位 + 爆发 | **124 帧，不要压缩** |
| 多镜叙事（四到五阶段） | 9–18s，**拆段做，每段 5–8s 甜点区** |

**要更快就提高 124 帧内的动作密度，不要缩时长。** 缩时长的代价：变招来不及"聚集→释放"、步型来不及重排（肢体畸变）、顶力帧被压没（碰撞感消失）。

---

## 五、分遍生产

```text
第一遍  出基础动作     Wushu Action + Combat Base V2（+ Weapon Combat / Spatial Physics）
第二遍  补特效（如需）  VFX Edit LoRA（触发词 vfx_edit:，强度 1.0）
第三遍  统一风格 + 收细节
```

**一次生成"高速招式 + 复杂特效 + 多角色 + 大位移"必然崩** —— 误差累积。
每遍只改一个变量，崩了才能定位。
