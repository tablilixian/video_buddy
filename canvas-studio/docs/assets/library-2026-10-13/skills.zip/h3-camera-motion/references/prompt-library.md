# Camera Motion LoRA 提示词库（完整 55 条）

**来源**：`Jojocodex/minimax-h3-Camera-Motion-lora` 附带的 `camera_motion_Prompt Library.md`
**性质**：**训练素材的原样标注**——直接复制效果与训练数据最接近，是这套 LoRA 最匹配的写法。

**结构**：`camera motion, [主体], [场景], [运镜], [光线/风格], [画质]`

**用法**：
- 想换内容 → 替换 `[主体], [场景]`，**保留逗号后的运镜短语**
- 想换运镜 → 只替换运镜短语，其余不动
- 混合使用 → 从不同条目里取"运镜短语"，拼到自己的主体与场景上

**分类索引**

| # | 类型 | 条数 |
|---|---|---|
| 一 | 推近 Push-in / Dolly-in | 12 |
| 二 | 拉远 Pull-back / Dolly-out | 6 |
| 三 | 推拉结合 Push + Pull | 4 |
| 四 | 环绕 Orbit | 6 |
| 五 | 跟拍 Tracking / Handheld | 8 |
| 六 | 航拍 Aerial / Drone | 8 |
| 七 | 升降 Crane / Tilt | 4 |
| 八 | 摇镜 Pan | 3 |
| 九 | 微距 / 特写 Close-up | 4 |

> **动作场面最常用的是第五类（跟拍/手持）与第一类（推近）**——它们训练最充分、最稳，也是打斗镜头的主力。

---

## 一、推近 Push-in / Dolly-in（12 条）

**1-1 屋顶格斗 · 慢推 + 微手持**（武术 / 夜景）
```
camera motion, a woman and a man in athletic wear, engaged in a dynamic rooftop martial arts fight with punches and defensive blocks, nighttime urban cityscape background, slow push-in to medium shot transitioning to slight pull-back as the woman falls, cinematic teal-orange grading, water droplet effects, sharp 4k, high production quality
```

**1-2 屋顶对战 · 慢推 + 横移跟拍**（武术 / 雨夜）
```
camera motion, a woman and a man in athletic wear, engaged in an intense martial arts sparring exchange on a wet rooftop at night, slow push-in combined with a subtle lateral tracking move following the fighters' footwork, cinematic teal-orange color grading, shallow depth of field, 4k, high quality
```

**1-3 仓库武术 · 推近 + 微环绕**（武术 / 工业废墟）
```
camera motion, two men in martial arts stances, facing each other in a tense standoff, abandoned industrial warehouse with peeling walls and debris, slow push-in with slight orbit around the fighters, cinematic god rays through windows, moody atmospheric lighting, 4k, high quality
```

**1-4 仓库格斗 · 推近至颈部特写**（武术 / 尘土光束）
```
camera motion, two martial artists in a dynamic kung fu fight, exchanging punches and kicks, blocking and dodging, abandoned industrial warehouse with dust and light beams, slow push-in to tight close-up on neck grab, cinematic dramatic lighting, 4k, high quality
```

**1-5 工业对决 · 推近推进**（近身格斗 / 烟雾）
```
camera motion, two men in a brutal hand-to-hand fight, one in black suit with white gloves throwing punches at opponent in blue jacket, gritty industrial warehouse interior with metal scaffolding and atmospheric haze, slow push-in dolly moving forward as the combat intensifies from striking to grappling, cinematic action drama, moody low-key lighting, 4k, high quality, sharp detail
```

**1-6 沙漠女战士 · 推近转拉远**（奇幻 / 金色时刻）
```
camera motion, slow push-in to close-up then dramatic pull-back to wide reveal, multiple female warriors in ornate fantasy armor and flowing robes, standing in formation across desert sand dunes before colossal ancient mechanical ruins, cinematic tracking shot with smooth dolly movement, photorealistic 3D render with golden hour lighting and warm amber color grade, 1080p, high quality AI-generated footage
```

**1-7 古装巷弄 · 低角度推近跟拍 + 俯仰**（古风 / 夜景灯笼）
```
camera motion, slow push-in and low-angle tracking shot, two figures in traditional Chinese robes facing each other in a tense emotional confrontation, ancient stone alleyway at night with warm lantern lighting, cinematic dolly-in with tilt-down to feet then pull-back to wide two-shot, photorealistic AI-generated footage, dramatic teal-orange color grading, 4k, high quality
```

**1-8 屋顶对决 · 急推变焦**（武术 / 霓虹天际线）
```
camera motion, a woman and a man in athletic wear, engaged in an intense rooftop martial arts fight, exchanging strikes and grappling, nighttime city skyline with glowing skyscrapers, aggressive push-in dolly zoom from wide to extreme close-up, cinematic teal-orange grading, dynamic action, 4k, high quality
```

**1-9 雪亭对峙 · 推近穿前景**（古风 / 水墨雪景）
```
camera motion, two figures in traditional Chinese robes, standing and facing each other inside a snow-covered pavilion, serene winter lakeside with willow branches and misty mountains, slow push-in through foreground willow leaves transitioning to extreme close-up of a hand holding a folding fan revealing a man's face, ethereal ink-wash painting aesthetic, soft cool-toned lighting, 4k, high quality
```

**1-10 微缩四季造景 · 推近滑轨**（微距 / 桌面）
```
camera motion, a miniature seasonal village diorama on a desk, transforming through autumn, winter, and spring with changing foliage and weather effects, office desk environment with computer monitor and stationery, slow push-in dolly glide across the diorama surface revealing each season transition, whimsical miniature aesthetic, soft natural lighting, 4k, high quality
```

**1-11 都市建筑 · 仰推环绕**（城市 / 云层）
```
camera motion, towering skyscrapers and modern cityscape, rising upward through dense urban canyon then orbiting around a central skyscraper, metropolitan downtown with glass high-rises and cloudy sky, dramatic tilt-up combined with aerial orbit and push-in toward building facade, cinematic drone cinematography, dynamic motion blur, 4k, high quality
```

**1-12 废弃仓库 · 手持推近**（动作 / 烟雾顶光）
```
camera motion, two men in a brutal hand-to-hand combat fight, exchanging punches and blocking strikes, dimly lit industrial warehouse with metal scaffolding, dynamic handheld camera with slight push-in following the action, atmospheric smoke and dramatic overhead lighting, cinematic action style, sharp detail, high quality
```

---

## 二、拉远 Pull-back / Dolly-out（6 条）

**2-1 仓库武术 · 拉远 + 轻环绕揭示环境规模**（工业 / 体积光）
```
camera motion, two men in a dynamic martial arts fight, exchanging kicks and punches with defensive blocks and dodges, inside a vast abandoned industrial warehouse with crumbling pillars and dramatic shafts of sunlight, slow pull-back combined with gentle orbit around the fighters revealing the full scale of the environment, cinematic gritty texture, natural volumetric lighting, high production quality
```

**2-2 工业对决 · 特写拉远至全景**（黑色电影）
```
camera motion, two men in a tense physical confrontation, one in a black suit throwing a punch at a man in a blue jacket who blocks and grapples back, dimly lit industrial warehouse with metal scaffolding and hanging fluorescent lights, atmospheric smoke and wet concrete floor, slow dramatic pull-back from a tight close-up to a wide establishing shot revealing the full environment, cinematic noir aesthetic, high contrast lighting, moody and gritty, sharp detail, 4k quality
```

**2-3 沙漠废土 · 低角度跟拍拉远**（后末日 / 暖金色）
```
camera motion, a post-apocalyptic warrior in a metal mask and brown cloak, racing a rusted quad bike across desert dunes, kicking up dust while pursued by an old sedan, vast arid wasteland with rocky ridges, dynamic tracking shot with low-angle close-up on wheels then pulling back to follow the ascent, cinematic action, warm golden tones, dust particles, 4k, high quality
```

**2-4 现代中庭 · 垂直下降**（建筑 / 光线）
```
camera motion, a modern architectural atrium with concentric circular balconies, descending vertically through the central void, revealing escalators and glass-paneled walkways below, aerial drone descent with smooth downward tilt and forward tracking, sleek contemporary interior, clean lines, bright natural lighting, 4k, high quality
```

**2-5 城市大桥 · 航拍拉远**（都市夜景 / 光轨）
```
camera motion, a massive illuminated cable-stayed bridge spanning a wide river through a glowing modern metropolis at night, aerial drone pull-back revealing the full scale of the bridge and city skyline with light trails from traffic, smooth ascending reveal shot, cinematic color grading, 4k, high quality
```

**2-6 空间展示 · 推后切航拍**（多场景 / 洋红青色调）
```
camera motion, no visible subject, establishing shots of interior and exterior spaces, gothic mansion hallway, cozy bedroom with neon-lit nightstand, surreal pink forest landscape, slow forward dolly push-in then cut to static wide aerial drone shot, cinematic color-graded with magenta-cyan palette, 4k, high quality
```

---

## 三、推拉结合 Push + Pull（4 条）

**3-1 屋顶对决 · 推近转双人镜 + 微环绕**（武术 / 湿天台）
```
camera motion, a man and a woman in athletic wear, sparring in a martial arts stance on a wet rooftop, night city skyline with glowing bokeh lights, slow push-in transitioning to a tighter two-shot with slight orbit, cinematic dramatic lighting, 4k, high quality
```

**3-2 工业对决 · 拉远后微推**（近身格斗 / 烟雾蒸汽）
```
camera motion, two men in a tense martial arts confrontation, one in black suit with sunglasses and white gloves exchanging punches and blocks with a man in blue jacket, dimly lit industrial warehouse interior filled with smoke and steam, slow pull-back revealing wider environment then subtle push-in, cinematic dramatic lighting, atmospheric haze, high production quality, sharp focus, moody noir aesthetic
```

**3-3 沙漠女战士 · 推近转拉远**（奇幻 / 金色时刻）
```
camera motion, slow push-in to close-up then dramatic pull-back to wide reveal, multiple female warriors in ornate fantasy armor and flowing robes, standing in formation across desert sand dunes before colossal ancient mechanical ruins, cinematic tracking shot with smooth dolly movement, photorealistic 3D render with golden hour lighting and warm amber color grade, 1080p, high quality AI-generated footage
```

**3-4 峡谷天桥 · 航拍拉远收尾**（自然）
```
camera motion, a traditional arched wooden covered bridge and a winding mountain canyon river, spanning a rocky stream with lush green forested cliffs, aerial drone pull-back ascending reveal shot from close-up to wide vista, cinematic natural lighting, vivid colors, 4k, high quality
```

---

## 四、环绕 Orbit（6 条）

**4-1 屋顶对决 · 平滑环绕（左→右）**（武术 / 霓虹）
```
camera motion, man and woman in athletic wear, sparring with punches and kicks in martial arts stances, wet rooftop at night, city skyline with neon lights in background, slow smooth orbit around the pair from left to right, cinematic color grading, shallow depth of field, 4k, high quality
```

**4-2 仓库武术 · 环绕 + 推拉**（工业 / 高对比）
```
camera motion, two martial artists in a dynamic kung fu fight, exchanging punches and kicks, blocking and dodging, abandoned industrial warehouse with debris and sunbeams through windows, slow orbiting camera around the fighters with subtle push-in and pull-back, cinematic desaturated color grade with high contrast, 4k, sharp detail, dramatic volumetric lighting
```

**4-3 仓库对决 · 环绕推近 + 光束尘埃**（工业）
```
camera motion, two martial artists in a dynamic kung fu fight, exchanging punches and kicks, blocking and dodging, abandoned industrial warehouse with dust particles in god rays, slow orbit around subjects with subtle push-in, cinematic lighting, 4k, high quality
```

**4-4 机械蜻蜓 · 航拍环绕跟随**（奇幻 / 航拍）
```
camera motion, a young woman riding a giant mechanical dragonfly, soaring through the air gripping the controls, lush green outdoor landscape below, aerial tracking shot following subject with smooth gimbal glide and slight push-in, cinematic CGI, vibrant colors, 4k, high quality
```

**4-5 钢铁战车 · 横移跟拍 + 速度模糊**（古装科幻 / 战场）
```
camera motion, two ancient Chinese noblemen in ornate armor and robes, riding a futuristic mechanical chariot at high speed, open battlefield with banners and mountains, dynamic tracking shot with lateral pan and speed blur, cinematic action, 4k, high production quality
```

**4-6 雪顶对决 · 剑扇对决 · 拉远环绕揭示全景**（武侠 / 漩涡能量）
```
camera motion, two martial artists in white and dark robes, dueling with sword and fan atop a snow-covered pavilion surrounded by swirling vortex energy, misty mountain landscape with weeping willow, dynamic pull-back from close-up vortex to wide establishing shot revealing the full rooftop confrontation, cinematic wuxia fantasy style, ethereal atmospheric lighting, 4k, high quality
```

> **4-6 是库里唯一的"剑 vs 扇 + 武侠"条目**，做双人对决镜头时优先参考它的运镜写法。

---

## 五、跟拍 Tracking / Handheld（8 条）

**5-1 屋顶格斗 · 手持推近跟拍**（武术 / 雨夜霓虹）
```
camera motion, a man and woman in athletic wear, engaged in intense martial arts combat with punches kicks and takedowns, nighttime rooftop with wet pavement reflecting neon city skyline, dynamic handheld camera with push-in and slight tracking following action, cinematic teal-orange color grading, sharp 4k, high quality
```

**5-2 屋顶对峙 · 慢横移跟拍**（武术 / 霓虹高楼）
```
camera motion, a man and woman in athletic wear, sparring with martial arts punches and blocks on a wet rooftop, nighttime city skyline with neon-lit skyscrapers, slow lateral tracking shot from left to right, cinematic color grading, dramatic lighting, 4k, high quality
```

**5-3 工业对决 · 手持推近跟随**（近身格斗 / 烟雾）
```
camera motion, two men in a brutal hand-to-hand fight, trading punches and grappling in close quarters, dimly lit industrial warehouse with smoke and metal scaffolding, dynamic handheld camera with slight push-in following the action, gritty cinematic texture, high contrast moody lighting, sharp 4k quality
```

**5-4 游乐场 · 手持转航拍**（日常 / 阳光）
```
camera motion, children and a young woman, playing and swinging in a sunny outdoor playground with sandbox and slide, handheld tracking shot transitioning to high-angle drone pull-back orbit, bright natural daylight, vibrant colors, vertical 9:16 composition, clear and sharp
```

**5-5 厨房 · 手持跟拍（纪录片）**（美食 / 微抖）
```
camera motion, chefs and a martial artist in white traditional attire, cooking with wok fire and chopping vegetables then striking martial arts pose, professional commercial kitchen and indoor studio, handheld camera with slight shake moving between scenes, dynamic documentary-style editing, vertical 9:16 format, moderate quality
```

**5-6 森林徒步 · 跟拍转固定 + 径向模糊**（自然 / 纪录片）
```
camera motion, hikers and a small white dog, trekking through a lush forest stream and wooded trail, stepping on mossy rocks, dense green forest with tall trees and rocky cliff walls, close-up push-in transitioning to tracking shot following from behind then cutting to a static medium shot with radial blur vignette effect, natural documentary style, vibrant colors, soft daylight, 4k, high quality
```

**5-7 岩洞探险 · 手持跟拍转微距上仰**（探险 / 洞内）
```
camera motion, a person in a yellow jacket and beige pants, walking through a dark cave passage, then close-up of a stalactite with a water droplet forming and hanging, underground cave environment with rocky formations, handheld tracking shot following subject then tilting up to macro on stalactite, intimate documentary style, dim atmospheric lighting with spotlight effect, vertical 9:16 aspect ratio, moderate quality
```

**5-8 骑兵冲锋 · 后方跟拍推近**（奇幻 / 能量隧道）
```
camera motion, armored cavalry soldiers on horseback, charging forward in formation through a swirling vortex tunnel, carrying black banners, surreal spiraling energy corridor with glowing particles, tracking/dolly push-in following the army from behind, cinematic epic fantasy, 4k, high quality, dramatic atmospheric lighting
```

---

## 六、航拍 Aerial / Drone（8 条）

**6-1 山川瀑布 · 航拍下降 + 水面前推**（自然 / 云雾）
```
camera motion, majestic green mountain peaks and misty valleys, aerial drone descending over cloud-wrapped ridges, low-angle water-level shot of splashing stream, two hikers crossing stone bridge, mountain forest with flowing creek, slow aerial push-in, water-level tracking, static wide, cinematic natural lighting, 4k, high quality
```

**6-2 雄鹰悬崖 · 航拍跟随转俯冲**（自然 / 峡谷）
```
camera motion, a large eagle gliding with wings spread wide, soaring and descending over a lush green mountain cliffside, aerial drone tracking shot following the bird then tilting down to a narrow mountain path where hikers rest against steep rock walls, vertical 9:16 format, natural daylight, vivid colors, sharp detail
```

**6-3 峡谷天桥 · 航拍拉远**（自然 / 河川）
```
camera motion, a traditional arched wooden covered bridge and a winding mountain canyon river, spanning a rocky stream with lush green forested cliffs, aerial drone pull-back ascending reveal shot from close-up to wide vista, cinematic natural lighting, vivid colors, 4k, high quality
```

**6-4 哥特庄园 · 航拍下降 + 前推入内**（哥特 / 粉树林）
```
camera motion, a grand gothic mansion with pink-tinted trees and an ornate interior hallway, revealed through descending aerial drone and forward tracking shot, exterior grounds transitioning to arched corridor with glowing pink and teal lighting, cinematic surreal atmosphere, 4k, high quality
```

**6-5 都市峡谷 · 仰拍上升 + 环绕**（城市 / 航拍）
```
camera motion, towering skyscrapers and modern cityscape, rising upward through dense urban canyon then orbiting around a central skyscraper, metropolitan downtown with glass high-rises and cloudy sky, dramatic tilt-up combined with aerial orbit and push-in toward building facade, cinematic drone cinematography, dynamic motion blur, 4k, high quality
```

**6-6 城市大桥 · 航拍拉远**（都市夜景 / 光轨）
```
camera motion, a massive illuminated cable-stayed bridge spanning a wide river through a glowing modern metropolis at night, aerial drone pull-back revealing the full scale of the bridge and city skyline with light trails from traffic, smooth ascending reveal shot, cinematic color grading, 4k, high quality
```

**6-7 机械蜻蜓 · 航拍跟随**（奇幻 / 绿地）
```
camera motion, a young woman riding a giant mechanical dragonfly, soaring through the air gripping the controls, lush green outdoor landscape below, aerial tracking shot following subject with smooth gimbal glide and slight push-in, cinematic CGI, vibrant colors, 4k, high quality
```

**6-8 峡谷收尾 · 航拍拉远**（自然 / 岩壁）
```
camera motion, a winding mountain canyon river, spanning a rocky stream with lush green forested cliffs, aerial drone pull-back ascending reveal shot from close-up to wide vista, cinematic natural lighting, vivid colors, 4k, high quality
```

---

## 七、升降 Crane / Tilt（4 条）

**7-1 城市天际线 · 仰升降 + 环绕**（城市 / 云层）
```
camera motion, towering skyscrapers and modern cityscape, rising upward through dense urban canyon then orbiting around a central skyscraper, metropolitan downtown with glass high-rises and cloudy sky, dramatic tilt-up combined with aerial orbit and push-in toward building facade, cinematic drone cinematography, dynamic motion blur, 4k, high quality
```

**7-2 古装巷弄 · 低角度仰推 + 俯仰**（古风 / 灯笼夜景）
```
camera motion, slow push-in and low-angle tracking shot, two figures in traditional Chinese robes facing each other in a tense emotional confrontation, ancient stone alleyway at night with warm lantern lighting, cinematic dolly-in with tilt-down to feet then pull-back to wide two-shot, photorealistic AI-generated footage, dramatic teal-orange color grading, 4k, high quality
```

**7-3 现代中庭 · 垂直下降 + 下俯**（建筑 / 现代）
```
camera motion, a modern architectural atrium with concentric circular balconies, descending vertically through the central void, revealing escalators and glass-paneled walkways below, aerial drone descent with smooth downward tilt and forward tracking, sleek contemporary interior, clean lines, bright natural lighting, 4k, high quality
```

**7-4 沙漠骑行 · 低角度跟拍 + 拉远**（后末日 / 暖色）
```
camera motion, a post-apocalyptic warrior in a metal mask and brown cloak, racing a rusted quad bike across desert dunes, kicking up dust while pursued by an old sedan, vast arid wasteland with rocky ridges, dynamic tracking shot with low-angle close-up on wheels then pulling back to follow the ascent, cinematic action, warm golden tones, dust particles, 4k, high quality
```

---

## 八、摇镜 Pan（3 条）

> **注意：摇镜是这套 LoRA 的弱项**（训练样本少）。以下三条都采用了"**主运镜 + 叠加摇镜**"的写法，正是为了规避这个弱项——照这个模式写，不要单独写 `pan left`。

**8-1 屋顶对决 · 推近 + 轻微右摇**（武术 / 雨夜）
```
camera motion, a woman and a man in athletic wear, practicing martial arts sparring on a wet rooftop at night, slow push-in with slight pan-right, cinematic gimbal glide toward the fighters, neon-lit city skyline backdrop with falling rain, dramatic high-contrast lighting, shallow depth of field, 4k, crisp and atmospheric quality
```

**8-2 庄园客厅 · 滑轨前推 + 右摇（空镜）**（室内 / 洋红蓝对比）
```
camera motion, an opulent mansion living room interior, showcasing luxurious furniture and decor, no people present, grand living space with sofas, ottoman, and large windows revealing surreal pink foliage outside, slow gimbal glide forward with subtle push-in and slight pan right across the room, cinematic color grading with dramatic magenta-blue contrast lighting, elegant and atmospheric, 4k, high quality
```

**8-3 微缩花溪 · 滑轨前推 + 右摇**（微距 / 桌面）
```
camera motion, a miniature diorama of a blossoming stream landscape with cherry trees, flowers, and a white egret, displayed on a desk among office items, slow gimbal glide forward and gentle pan right across the detailed tabletop scene, shallow depth of field, warm natural sunlight, soft focus background, dreamy miniature aesthetic, 4k, high quality
```

---

## 九、微距 / 特写 Close-up（4 条）

**9-1 青蛙池塘 · 拉远微距 + 快速跟焦**（微距 / 桌面池塘）
```
camera motion, a small green frog perched on a rock in a miniature indoor pond, watching a dragonfly hover and land on a reed leaf, desktop diorama with lily pads mossy wood and office background, smooth pull-back revealing wider scene then rapid motion blur tracking the dragonfly, cinematic shallow depth of field, 4k, high quality
```

**9-2 古装折扇 · 穿前景推近至特写**（古风 / 雪景）
```
camera motion, slow push-in through foreground willow leaves transitioning to extreme close-up of a hand holding a folding fan revealing a man's face, snow-covered pavilion, serene winter lakeside with willow branches and misty mountains, ethereal ink-wash painting aesthetic, soft cool-toned lighting, 4k, high quality
```

**9-3 工业对决 · 特写推近转双人中景**（近身格斗 / 烟雾）
```
camera motion, two men in a brutal close-quarters fight, one in black suit with white hand wraps grappling and striking opponent in blue jacket, dim industrial warehouse filled with smoke, slow push-in to tight close-up then pull-back to medium two-shot, handheld feel with subtle drift, gritty cinematic noir lighting, sharp 4k quality
```

**9-4 岩洞钟乳石 · 上仰至微距**（自然 / 探险）
```
camera motion, close-up of a stalactite with a water droplet forming and hanging, underground cave environment with rocky formations, tilting up to macro on stalactite, intimate documentary style, dim atmospheric lighting with spotlight effect, vertical 9:16 aspect ratio, moderate quality
```

---

## 附：运镜短语速取表（脱离完整例句直接用）

从 55 条里拆出的**可复用运镜短语**，可直接嫁接到自己的主体与场景上：

| 需求 | 短语 |
|---|---|
| 慢推近 | `slow push-in` · `slow push-in dolly moving forward` · `slow push-in to medium shot` |
| 推近 + 跟随动作 | `dynamic handheld camera with slight push-in following the action` |
| 推近 + 横移 | `slow push-in combined with a subtle lateral tracking move following the fighter's footwork` |
| 推近 + 微环绕 | `slow push-in with slight orbit around the fighters` |
| 推近至特写 | `slow push-in to tight close-up` · `aggressive push-in dolly zoom from wide to extreme close-up` |
| 穿前景推近 | `slow push-in through foreground leaves transitioning to extreme close-up` |
| 慢拉远 | `slow pull-back` · `slow dramatic pull-back from a tight close-up to a wide establishing shot` |
| 拉远 + 环绕 | `slow pull-back combined with gentle orbit around the fighters revealing the full scale of the environment` |
| 推后拉 | `slow push-in to close-up then dramatic pull-back to wide reveal` |
| 环绕 | `slow smooth orbit around the pair from left to right` · `slow orbit around subjects with subtle push-in` |
| 手持跟拍 | `dynamic handheld camera with push-in and slight tracking following action` |
| 横移跟拍 | `slow lateral tracking shot from left to right` |
| 后方跟拍推近 | `tracking/dolly push-in following the subject from behind` |
| 摇臂式上升 | `dramatic tilt-up combined with aerial orbit and push-in` |
| 垂直下降 | `descending vertically through the central void` · `aerial drone descent with smooth downward tilt and forward tracking` |
| 航拍拉远 | `aerial drone pull-back ascending reveal shot from close-up to wide vista` |
| 低角度跟拍 | `dynamic tracking shot with low-angle close-up then pulling back` |
| 摇镜（必须叠加） | `slow push-in with slight pan-right` · `slow gimbal glide forward with subtle push-in and slight pan right` |
| 微距上仰 | `tilting up to macro` |
