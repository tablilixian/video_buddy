#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Qwen-Image-2.1 rewritten-prompt contract validator.

Offline only: pure standard library, no network, no subprocess. It reads a JSON
object (or a JSONL file) produced by the qwen-image-2-1-prompt skill and checks it
against the output contract in Qwen's official system prompts.

Runtime use is optional. Run it when building a pipeline, or when the user asks
for validation -- not on every conversational reply.

Usage:
    python validate_prompt.py --json '{"rewritten_prompt":"...","wh_ratio":"3:2"}'
    python validate_prompt.py --file out.jsonl --task edit
    python validate_prompt.py --json "..." --quiet

Exit code: 0 = no errors, 1 = at least one error.
"""

from __future__ import annotations

import argparse
import json
import re
import sys

# --------------------------------------------------------------------------- #
# Rules
# --------------------------------------------------------------------------- #

FIELDS_T2I = ("rewritten_prompt", "wh_ratio")
FIELDS_EDIT = ("rewritten_prompt", "wh_ratio", "ratio_follow")

QUALITY_BOOSTERS = (
    "masterpiece",
    "8k",
    "4k",
    "highly detailed",
    "award-winning",
    "award winning",
    "ultra detailed",
    "best quality",
    "超高清",
    "杰作",
)

INSTRUCTION_TELLS = ("you should", "make sure", "the ai should", "please create")

RATIO_LIKE = re.compile(r"(?<![\d.])\d{1,2}\s*[:：]\s*\d{1,2}(?![\d])")
PIXEL_LIKE = re.compile(r"(?<![\d.])\d{3,5}\s*[x×*]\s*\d{3,5}(?![\d])")
RES_WORDS = re.compile(r"(?<![a-z0-9])(2k|4k|8k|1080p|720p|2160p)(?![a-z0-9])", re.I)
WH_RATIO_OK = re.compile(r"^\d{1,2}:\d{1,2}$")
RATIO_FOLLOW_OK = re.compile(r"^<image([1-9]|10)>$")
CJK = re.compile(r"[\u3400-\u4dbf\u4e00-\u9fff\u3040-\u30ff\uac00-\ud7af]")
LATIN_WORD = re.compile(r"[A-Za-z]{2,}")
QUOTED = re.compile(r'"([^"]*)"')

# The official contract lets standardized units and given proper nouns stay in
# Latin script inside otherwise-Chinese rendered text. Those are NOT code-switching,
# so they must not trip the monolingual check.
UNIT_ALLOWLIST = {
    # units
    "mm", "cm", "dm", "km", "mg", "kg", "hz", "khz", "mhz", "ghz", "db", "ma",
    "mah", "mw", "kw", "kv", "nm", "min", "sec", "px", "dpi", "ppi",
    # connectivity / codec / standards
    "usb", "hdmi", "nfc", "rgb", "rgba", "cmyk", "bluetooth", "ldac", "aac",
    "sbc", "aptx", "anc", "led", "oled", "lcd", "ip",
}


def latin_words(text: str) -> list[str]:
    """Latin words that are NOT standardized units or proper nouns."""
    return [t for t in LATIN_WORD.findall(text) if t.lower() not in UNIT_ALLOWLIST]



class Report:
    def __init__(self) -> None:
        self.errors: list[str] = []
        self.warnings: list[str] = []
        self.notes: list[str] = []

    def error(self, msg: str) -> None:
        self.errors.append(msg)

    def warn(self, msg: str) -> None:
        self.warnings.append(msg)

    def note(self, msg: str) -> None:
        self.notes.append(msg)

    @property
    def ok(self) -> bool:
        return not self.errors


def _check_common(obj: dict, task: str, rep: Report) -> None:
    expected = FIELDS_T2I if task == "t2i" else FIELDS_EDIT
    keys = set(obj.keys())
    missing = [k for k in expected if k not in keys]
    extra = sorted(keys - set(expected))
    if missing:
        rep.error(f"缺少字段: {', '.join(missing)}")
    if extra:
        rep.error(f"多余字段: {', '.join(extra)} (契约只允许 {', '.join(expected)})")

    prompt = obj.get("rewritten_prompt")
    if not isinstance(prompt, str) or not prompt.strip():
        rep.error("rewritten_prompt 缺失或为空")
        return

    # single paragraph, no newline
    if "\n" in prompt or "\r" in prompt:
        rep.error("rewritten_prompt 含换行符 (契约要求单段落无 \\n)")

    if "..." in prompt or "\u2026" in prompt:
        rep.warn("rewritten_prompt 出现省略号，检查是否被截断")

    # Straight double quotes mark text that will be RENDERED INTO the image.
    # That content is literal -- a spec label, a screen readout, a badge -- so the
    # hype-word and metadata bans apply to the narrative prose around it, not to it.
    buf = list(prompt)
    for s, e in (m.span() for m in QUOTED.finditer(prompt)):
        for i in range(s, e):
            buf[i] = " "
    narrative = "".join(buf)
    quotes = QUOTED.findall(prompt)
    low_narrative = narrative.lower()

    for w in QUALITY_BOOSTERS:
        if w in low_narrative:
            rep.error(f"rewritten_prompt 正文含质量粉饰词: {w!r}")

    for tell in INSTRUCTION_TELLS:
        if tell in low_narrative:
            rep.warn(f"rewritten_prompt 正文出现指令语气 {tell!r} (T2I 契约要求观察者陈述)")

    for m in RATIO_LIKE.finditer(narrative):
        rep.warn(f"rewritten_prompt 正文出现比例样式文本 {m.group(0)!r} — 可能误报(如时间 10:10)，请人工确认")
    for m in PIXEL_LIKE.finditer(narrative):
        rep.error(f"rewritten_prompt 正文出现像素尺寸 {m.group(0)!r}")
    for m in RES_WORDS.finditer(narrative):
        rep.error(f"rewritten_prompt 正文出现分辨率词 {m.group(0)!r}")

    for q in quotes:
        low_q = q.lower()
        for w in QUALITY_BOOSTERS:
            if w in low_q:
                rep.warn(f"引号内出现质量词 {w!r} — 若它是画面里要渲染的规格或徽标文字则属正常，非对画面质量的自夸")
        for rx, what in ((PIXEL_LIKE, "像素尺寸"), (RES_WORDS, "分辨率词"), (RATIO_LIKE, "比例样式")):
            for m in rx.finditer(q):
                rep.warn(f"引号内出现{what} {m.group(0)!r} — 若这是要渲染进图的规格/读数文字则属正常，它不是画幅元数据")
        stray = latin_words(q)
        if CJK.search(q) and stray:
            rep.warn(f"引号内可能中英混排: {q!r}（拉丁词: {', '.join(stray)}）— 除非用户明确要求双语，否则应为单语。单位与专有名词已自动豁免。")

    # wh_ratio
    wh = obj.get("wh_ratio", "")
    rf = obj.get("ratio_follow", "") if task == "edit" else ""

    if not isinstance(wh, str):
        rep.error("wh_ratio 必须是字符串")
        wh = ""
    if wh:
        if not WH_RATIO_OK.match(wh):
            rep.error(f"wh_ratio 格式异常: {wh!r} (期望 'W:H')")

    if task == "edit":
        if not isinstance(rf, str):
            rep.error("ratio_follow 必须是字符串")
            rf = ""
        if rf and not RATIO_FOLLOW_OK.match(rf):
            rep.error(f"ratio_follow 格式异常: {rf!r} (期望 '<image1>'..'<image10>')")

        if wh and rf:
            rep.error("wh_ratio 与 ratio_follow 同时有值 — 契约要求互斥")
        if not wh and not rf:
            rep.error("wh_ratio 与 ratio_follow 同时为空 — 必须且只能有一个带值")
        if wh:
            rep.note(f"画布: 模型自选比例 {wh}")
        elif rf:
            rep.note(f"画布: 沿用 {rf} 的画幅")

        low_prompt = prompt.lower()
        if rf and "outpaint" not in low_prompt and any(
            k in prompt for k in ("扩图", "延伸画面", "向外扩展")
        ):
            rep.warn("疑似扩图任务但未在指令中显式写出 outpainting")


def validate_obj(obj: object, task: str, rep: Report, label: str) -> None:
    if not isinstance(obj, dict):
        rep.error(f"{label}: 顶层不是 JSON 对象")
        return
    _check_common(obj, task, rep)


def parse_input(text: str) -> list[tuple[str, object]]:
    """Return [(label, obj)]. Accepts a single JSON object or JSONL."""
    text = text.strip()
    if not text:
        raise ValueError("输入为空")
    if text.startswith("```"):
        raise ValueError("输入带 markdown 代码围栏 — 契约要求纯 JSON，无围栏")
    try:
        return [("payload", json.loads(text))]
    except json.JSONDecodeError:
        pass
    rows: list[tuple[str, object]] = []
    for i, line in enumerate(text.splitlines(), 1):
        line = line.strip()
        if not line:
            continue
        try:
            rows.append((f"line {i}", json.loads(line)))
        except json.JSONDecodeError as exc:
            rows.append((f"line {i}", {"__parse_error__": str(exc)}))
    if not rows:
        raise ValueError("既不是合法 JSON，也不是合法 JSONL")
    return rows


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Validate Qwen-Image-2.1 rewritten-prompt contract")
    src = ap.add_mutually_exclusive_group(required=True)
    src.add_argument("--json", help="inline JSON string")
    src.add_argument("--file", help="path to a .json or .jsonl file")
    ap.add_argument("--task", choices=("t2i", "edit"), default="t2i",
                    help="which contract to check against (default: t2i)")
    ap.add_argument("--quiet", action="store_true", help="only print the verdict line")
    args = ap.parse_args(argv)

    if args.file:
        try:
            with open(args.file, "r", encoding="utf-8-sig") as fh:
                raw = fh.read()
        except FileNotFoundError:
            print(f"[ERROR] 文件不存在: {args.file}")
            print("        在 Windows 上请传 Windows 路径（如 C:/... 或 .\\...），")
            print("        Git Bash 的 /tmp 之类路径 Python 解析不了。")
            return 1
        except OSError as exc:
            print(f"[ERROR] 无法读取 {args.file}: {exc}")
            return 1
    else:
        raw = args.json

    try:
        rows = parse_input(raw)
    except ValueError as exc:
        print(f"[ERROR] {exc}")
        return 1

    rep = Report()
    for label, obj in rows:
        if isinstance(obj, dict) and "__parse_error__" in obj:
            rep.error(f"{label}: JSON 解析失败 — {obj['__parse_error__']}")
            continue
        validate_obj(obj, args.task, rep, label)

    if not args.quiet:
        print(f"task={args.task}  rows={len(rows)}")
        for n in rep.notes:
            print(f"  [INFO]  {n}")
        for w in rep.warnings:
            print(f"  [WARN]  {w}")
        for e in rep.errors:
            print(f"  [ERROR] {e}")

    if rep.ok:
        print(f"PASS  ({len(rep.warnings)} warning{'s' if len(rep.warnings) != 1 else ''})")
        return 0
    print(f"FAIL  ({len(rep.errors)} error{'s' if len(rep.errors) != 1 else ''})")
    return 1


if __name__ == "__main__":
    try:
        sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]
    except Exception:
        pass
    raise SystemExit(main())
