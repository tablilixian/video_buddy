# 崇礼国庆初秋短片 · Storyboard

> **片名**：崇礼，不止一场雪
> **用途**：AI 生成短片（T2VA / I2VA / Ref2VA）
> **结构**：6 个分镜 / 11 shots / 30.00s
> **故事线**：一家三口的两天一夜（父亲陆行 · 母亲周宁 · 12 岁女儿夏夏）
> **画幅**：16:9 横屏（全片统一）
> **旁白**：磁性男声，5 句 45 字，口播 14.1s，留白 15.9s
> **收尾**：末镜使用横版海报版式，同时承担信息与落版
> **版本**：v3.8

| 项目 | 规格 |
|---|---|
| 总时长 | 30.00s |
| 分镜数 | 6 个（叙事单元） |
| shot 数 | 11 个（每 2–3 秒一条；末镜 2.0s） |
| 画幅 | 16:9 横屏 |
| 运镜纪律 | 一条 prompt 只写一个 camera motion |
| 旁白 | 5 句 45 字，口播 14.1s，留白 15.9s |
| 出镜角色 | 3 位（一家三口），各自先出标准形象图 |
| 画面文字 | 右上角景点角标 + 末镜海报（S11） |

---

## 00 季节前提

**全片没有一片雪。** 崇礼雪季 11 月起，本片生成的是 10 月初的初秋。

- 服装按秋装设计，体感 0–14℃，山顶风大（角色卡已按此设定）
- 所有 prompt 里**禁止出现 snow / winter / ski / snowfall**，一次都不行
- 色调是"还没黄透"的初秋：黄绿交界，不是深秋的金红
- 天空用暖调浅青，不要用冬季那种冷冽深蓝

---

## 01 景点亮点清单

前 9 个是正片阵容，后 6 个是备选（生成效果不理想时替换）。每一条都标了对应 shot、光线条件与构图要点——这三项要直接写进 prompt。

### ★ 梧桐大道（太子城）

两公里长的道路两侧密植法国梧桐，枝叶合拢成拱形隧道，整条路被焦糖色落叶铺满，厚到看不见路面。全片纵深最强的一处。

- **用在**：S02
- **光线**：上午低角度斜光，从枝隙漏下密集光斑
- **构图**：纵向隧道，让道路把视线带向画面深处

### ★ 太舞滑雪小镇（营岔村）

北美欧式风格，红色坡屋顶木屋依山而建，秋季屋前屋后的落叶松与白桦转成金黄，红顶与黄叶同时入画。半山腰有巨型 THAIWOO 字母地标与"听山"大耳机雕塑。

- **用在**：S03
- **光线**：晴日，山间通透
- **构图**：缆车轿厢视角，从下缘仰摇，脚下是层林

### ★ 玉石梁高山草甸（2160 米）

可乘车抵达的最高观景点之一。初秋草甸绿与浅金交错，四周山脊线连绵，冷杉深绿压在天际。海拔高、空气通透，云影在草甸上移动很快。

- **用在**：S04
- **光线**：下午斜射光把草甸照出纹理
- **构图**：人小山大，人物只占画面一侧，留出大片山脊

### ★ 翠云山万亩白桦林

树龄大、林密、地面干净。10 月初正处在黄绿交界到全黄之间——阳面暖金、阴面留一层黄绿，逆光下叶片边缘透出一圈光。林下有木栈道、溪流与瀑布。

- **用在**：S05
- **光线**：侧逆光穿透林间，叶片透光发亮
- **构图**：垂直升起穿过树冠，把地面落叶与空中叶雨串成一条线

### ★ 喜鹊梁（2078 米）

开阔的山脊草甸，成排巨型白色风机沿山脊排开。几乎没有光污染，夜里可见银河——同一个地点，白天与深夜是两张完全不同的画。

- **用在**：S06（日间骑行）、S10（夜间银河）
- **光线**：日间用暖金侧光；夜间用星空 + 风机剪影
- **构图**：风机在行进线上依次退后，形成节奏

### ★ 富龙四季小镇（风铃乐谷）

19 栋彩色欧式建筑沿中心湖环湖而建，秋季湖水澄澈，建筑与红叶一起倒映。全片最可控的一处夜景。

- **用在**：S08
- **光线**：黄昏，市集暖色串灯亮起
- **构图**：从摊位高度升起，越过屋顶俯瞰整个山谷小镇

### ★ 阿那亚·崇礼（山谷音乐厅）

极简混凝土曲面音乐厅卧在坡地上，几乎不用颜色，靠曲面与光影说话，与周围浓烈的秋色形成强反差。旁边有山间文创市集与面包咖啡馆。

- **用在**：S09
- **光线**：暮色，只剩天边一道橙
- **构图**：绕木桌极慢环绕，把人与身后的曲面建筑一起纳入

### ★ 京张高铁沿线

列车出北京后穿越燕山山脉，多次进出隧道群。车窗外的山体由灰绿渐次转为金黄，隧道骤暗与重见光明之间是天然的硬切节奏。

- **用在**：S01
- **光线**：午后，车厢内暗、窗外亮
- **构图**：中景，三人并排占画面下三分之二，靠窗一侧留出车窗与窗外的秋色；人物面向车窗，用侧逆光勾出三张脸的轮廓

### ★ 密苑云顶乐园

冬奥赛场，冬季雪道在秋季变身高山草甸，缆车直达山顶，山间花海与风车步道随处可逛。**太舞缆车画面不理想时的替换点。**

- **用在**：S03 备选

### 备选景点

| 景点 | 秋季亮点 | 可替换 |
|---|---|---|
| 草原天路桦皮岭段 | 高山风车公路，漫山秋色，观景台视野开阔 | S06 |
| 和平森林公园 | 白桦与落叶松混交林，层林尽染 | S05 |
| 国家跳台滑雪中心"雪如意" | S 形曲线坐落山间，暮色中灯带亮起，辨识度最高 | 末镜备选 |
| 万龙滑雪场（红花梁） | 山道两侧落叶松转金 | S06 |
| 华侨冰雪博物馆 | 小众人文，室内场景 | 备拍 |
| 太子城遗址 | 金代行宫遗址，安静去处 | 备拍 |

---

## 02 视觉规范

**全片基调：初秋的暖意。** 不是深秋的萧瑟，也不是冬天的冷冽——是十月头几天那种还留着暑气余温的暖。太阳角度低，光又长又软，照在还没完全变黄的叶子上，整座山像被镀了一层蜜。

**画面质感（写进 prompt 的风格句）**

- 1K 起步，主景 2K
- 长焦压缩为主，广角只给 2 个大景
- 人物段落用浅景深
- 轻微胶片颗粒；禁止冷调、禁止青橙对撞

**运镜纪律**

- **一条 prompt 只写一个 camera motion**，不叠加第二个
- 可用运动：`Push in` `Pull out` `Crane up` `Truck` `Tracking` `Tilt up` `Pan` `Pedestal up` `Arc` `Orbit` `Static`
- 全部为慢速机械运动
- 禁止 handheld shake、禁止 jump cut

**光与色（写进 prompt 的风格句）**

- 低角度逆光：让叶片透光、让空气里的微尘变成金的
- 色温偏暖，prompt 里写 `warm golden hour light` / `warm autumn backlight`
- 阴影保留暖褐，不要纯黑，更不要偏蓝

**色彩脚本**（冷暖比 8:2）

| 色 | 值 | 用途 |
|---|---|---|
| 暖褐 | `#4A3A28` | 压场暗部 |
| 蜜金 | `#E8B04B` | 主色，初秋阳光与白桦 |
| 琥珀 | `#C98A3C` | 梧桐落叶、木屋、市集灯 |
| 赭红 | `#B4552E` | 女儿的红围巾、未褪尽的枫叶 |
| 暖青 | `#8FB8C4` | 唯一冷色，只给高海拔天空与夜景 |

> **暖要来自光，不来自后期。** 在 prompt 里把光写暖（`warm golden backlight`），而不是生成完再套暖色滤镜——套出来的暖会让皮肤发橙、叶子变成塑料黄，是"廉价暖"。

---

## 03 旁白稿 · 磁性男声

全稿 **5 句 45 字，口播 14.1 秒**，只占全片 47%，剩下 15.9 秒一句话都不说。话越少，每句越重。

**声线规格**：男声 / 32–40 岁 / Baritone / 3.2 字每秒　——　这是一家三口里，父亲的声音

| shot | 时码 | 旁白 | 对应画面 | 语气提示 |
|---|---|---|---|---|
| S01 | 0.00–2.50 | **留白** | 京张高铁车厢，三人并排坐窗边，玻璃由暗转亮 | 开场不给人声，靠光色变化与三人的微表情抓人 |
| S02 | 3.0s | 北京出发，一小时。 | 梧桐大道，焦糖色落叶隧道 | 落在落叶隧道展开的那一刻，句尾下沉 |
| S03 | 5.50–8.00 | **留白** | 太舞缆车爬升，层林尽染 | 配乐在此进入 |
| S04 | 8.5s | 这里的秋天，比雪先到。 | 玉石梁草甸，三人站定在开阔景 | 本片立意句，读稳、不加力 |
| S05 | 11.5s | 十月叶子，十一月雪。 | 翠云山白桦林，母女接落叶 | 两句对仗，中间留 0.3s |
| S06 | 14.00–16.50 | **留白** | 喜鹊梁，父女骑行 | 只留链条声与车铃 |
| S07 | 17.0s | 山顶的落日，一天一场。 | 星芒图书馆，三人并排看落日 | 回落到全片最慢 |
| S08 | 19.50–22.00 | **留白** | 富龙小镇黄昏市集 | 交给市集人声与音乐 |
| S09 | 22.00–25.00 | **留白** | 阿那亚露台，一家三口野餐 | 只留杯碟与风声 |
| S10 | 25.00–28.00 | **留白** | 喜鹊梁星空，风机剪影 | 交给星空与夜灯 |
| S11 | 28.2s | 崇礼，不止一场雪。 | 海报（含 slogan 与三条出行信息） | 落版句，读满 1.8 秒 |

**合成要求**：句间保留 0.4–0.6 秒自然气口，不要压死。旁白全程画外音，画面里不出现说话人。

> **本版删掉了原第 4 句「出站就有接驳车，免费」。** 末镜海报上已经把「约 1 小时 / 约 200 公里 / 0–14℃」三条信息写成大字，旁白再念一遍是重复；而末镜只有 2 秒，念不下 11 个字。信息交给眼睛，旁白只留情绪——这是本版把口播从 6 句压到 5 句的原因。
>
> **如果想要保留那句信息**，可以把 S11 的旁白换成「出站就有接驳车，免费。」（需把末镜拉到 3 秒），落版句则完全交给海报上的 slogan 文字。

> 落版句"不止一场雪"是双关：既指冬季滑雪，也指秋天这另一种玩法。它是全片立意的收口，不要改。

---

## 04 分镜脚本

两级结构：**分镜**是叙事单元（6 个），**shot** 是生成的一次连续画面（11 个）。前五个分镜各 2 条、互为补充，末个分镜只有 1 条——全片以海报收尾。任意一条出废了都能单独重出，不牵连同段另一条。

> 若某个分镜需要更多机位，可在段内拆成 3–4 个 shot，全片上限 14 条。

### 分镜 01 · 出发 ｜ 0.00 – 5.50s ｜ 2 shots

**叙事任务**：把"一小时"砸出来。

#### S01 ｜ 0.00 – 2.50s ｜ 京张高铁

- **画面**：车厢内**中景**，一家三口并排坐在靠窗一侧——夏夏在最里靠窗，周宁居中，陆行靠过道。窗外城市的灰白楼群正一格一格退去，玻璃上的反光转成山野的金；玻璃由暗转亮那一瞬，整片秋林显现。三人的侧脸同时被窗光打亮，光从靠窗的夏夏向外逐级减弱，陆行一侧最沉。**三人的微表情依次发生**：陆行先从刺眼的隧道暗里松开眼睛、眉毛极轻抬了一下，嘴角几乎没有幅度地松了松，随后把视线从窗外移向身边的妻女；周宁几乎同时转头看窗外，唇角先抬、苹果肌随后鼓起，眼角挤出两道浅纹，反应比丈夫外放半格；夏夏是最后被光"叫醒"的——眼睛先睁大，嘴唇微微分开，身体不自觉前倾一点，一只手撑在扶手上。三人都不说话。
- **运镜**：`Push in` 缓慢推近三人与车窗，推距不超过画面宽度的 15%。
- **旁白**：（无）
- **声音**：车轮碾过轨道接缝的规律节拍，先入画 0.3 秒；进隧道时气流轰鸣短暂压过一切。
- **prompt**：`medium shot inside a warm-toned train carriage: a family of three seated side by side facing the window, the twelve-year-old girl at the window, the mother in the middle, the father on the aisle side, warm window light brightening their faces from window to aisle; the girl's eyes widening and lips parting slightly as she leans in with one hand on the armrest, the mother's lip corners lifting into a faint smile as she turns to the glass, the father's brow relaxing as he shifts his gaze from the window to his family; outside, city grey turning to golden autumn hills, brief tunnel darkness, slow push-in, 35mm shallow focus, film grain, no lens flare`

#### S02 ｜ 2.50 – 5.50s ｜ 梧桐大道

- **画面**：梧桐大道，两公里长的焦糖色落叶隧道，路面几乎被落叶完全覆盖。低角度斜光从枝叶缝隙漏下来，在落叶上打出密集亮斑，一路退向远处成一条光的通道。车轮卷起的落叶在逆光里翻飞，每片都镶着金边。（本条 3.0 秒，比常规 shot 多半秒，给隧道纵深留出展开时间。）
- **运镜**：`Tracking` 贴地跟随前行。
- **旁白**：北京出发，一小时。
- **声音**：落叶被碾碎的脆响 + 远处林涛；要"干"，不加混响。
- **prompt**：`extreme low tracking shot along a two-kilometre plane-tree avenue, caramel fallen leaves burying the road, dappled sunlight through the arching canopy, backlit leaf litter swirling, ground-level 20cm, warm autumn palette, film grain`

---

### 分镜 02 · 登高 ｜ 5.50 – 11.00s ｜ 2 shots

**叙事任务**：全片最开阔的一个视野。

#### S03 ｜ 5.50 – 8.00s ｜ 太舞缆车

- **画面**：太舞滑雪小镇的观光缆车缓缓爬升。脚下是小镇错落的红色坡屋顶木屋，屋前屋后的落叶松与白桦已转金黄。镜头从轿厢底部仰摇升起，层林尽染逐层铺开——近处赭红五角枫，中景整片金黄白桦，远处冷杉墨绿压住天际线。半山腰的 THAIWOO 巨型字母从画框下缘滑过。
- **运镜**：`Tilt up` 仰摇上升。
- **旁白**：（无）配乐在此进入。
- **声音**：缆索金属摩擦、轿厢轻微晃动；山风随高度收紧，风声里有白桦叶的哗啦。
- **prompt**：`gondola cabin ascending over Thaiwoo resort village, red pitched roofs below, layered autumn forest unfolding — russet maple near, golden birch mid, dark fir at the skyline, camera tilts up with the ascent, clear warm autumn air, cinematic wide`

#### S04 ｜ 8.00 – 11.00s ｜ 玉石梁 2160m

- **画面**：海拔 2160 米的玉石梁高山草甸，绿与浅金交错的过渡色向四周铺到天际。**三人在全片第一处开阔景里站定**：陆行站在最外侧，夏夏站在父母中间偏前一点，抬手挡着风、另一只手指向远处的山脊；周宁站在她侧后方，抬手把她被风吹到脸上的碎发别到耳后。风吹得三人衣角一起朝同一侧飘。天空是暖调的通透浅青，远山层次清晰。（本条 3.0 秒。）
- **运镜**：`Truck` 横向平移，三人固定中景，背景山脊在身后缓缓流转。
- **旁白**：这里的秋天，比雪先到。
- **声音**：草甸高空风，一记远寺钟声不解释来源；孩子一句听不清的问话被风削掉一半。
- **prompt**：`family of three on a 2160-metre alpine meadow: father at the outer edge, the twelve-year-old girl in the centre front shielding her eyes from the wind and pointing at the distant ridge, mother standing just behind her tucking the girl's wind-blown hair behind her ear, wind pulling all three coats the same direction, green and pale-gold early-autumn grassland, warm light, lateral truck move, wide cinematic`

---

### 分镜 03 · 秋色 ｜ 11.00 – 16.50s ｜ 2 shots

**叙事任务**：两种颜色，一次奔跑。

#### S05 ｜ 11.00 – 14.00s ｜ 翠云山白桦

- **画面**：白桦原始森林。初秋的白桦还没全黄，黄绿相间、由浅到深，逆光下叶片边缘透出一圈暖金。一阵风从林深处推进，先落的叶子成片飘下，慢动作里每片都能数清叶脉。**夏夏走在前面，停下脚步、仰头伸手接住一片正在落下的叶子，摊在掌心里看；周宁跟在半步远的地方看着。**（本条 3.0 秒。）
- **运镜**：`Pedestal up` 垂直升起，穿过林梢。
- **旁白**：十月叶子，十一月雪。
- **声音**：叶片沙沙由近及远，风穿过树干空腔的低频共鸣；孩子的脚步踩在落叶上。
- **prompt**：`early-autumn virgin birch forest, yellow-green leaves with warm gold rim light, a gust shaking down a flurry of leaves in slow motion, a twelve-year-old girl in a ginger-yellow windbreaker and red scarf pausing ahead, catching one falling leaf in her open palm and looking down at it, mother half a step behind, camera pedestals up through the canopy, shallow depth of field`

#### S06 ｜ 14.00 – 16.50s ｜ 喜鹊梁骑行

- **画面**：喜鹊梁山脊草甸，海拔 2078 米，成排巨型白色风机沿山脊排开。**父女俩并排沿草甸边缘的土路骑过来——夏夏在内侧，身体压得很低、两条腿蹬得飞快；陆行压在外侧半个车身的位置，两人速度一致。** 车轮后扬起掺着落叶与碎草的暖尘，蜜金与赭红在两侧快速掠过，只有她保持清晰。
- **运镜**：`Pan` 水平摇摄跟随她穿过山脊，甩出画面后留空半秒。
- **旁白**：（无）
- **声音**：两辆车的链条声、女儿短促的呼吸与偶尔一记车铃；背景是风机低频的呼呼声。
- **prompt**：`father and twelve-year-old daughter riding side by side along a high ridge meadow at 2078 metres, the girl on the inside leaning low and pedalling hard, the father half a bike-length out on the outside matching her pace, a row of giant white wind turbines along the ridge line, dust and leaves kicked up behind the wheels, girl sharp against blurred golden and russet foliage, pan with the riders`

---

### 分镜 04 · 落日 ｜ 16.50 – 22.00s ｜ 2 shots

**叙事任务**：全片情绪的最高点，然后落下来。

#### S07 ｜ 16.50 – 19.50s ｜ 星芒图书馆落日

- **画面**：山顶的星芒玻璃图书馆，几何星芒形玻璃立面朝西而立。落日卡在山脊线上，玻璃把整轮落日折成一地碎金，光斑在地面缓缓移动。**三个人并排站在露台栏杆边——陆行端着杯子，夏夏两手搭在木栏杆上、身体前倾看落日，周宁站在她身后半步的位置。** 暖光勾出三人的侧脸轮廓，太阳在 3 秒内沉到山脊以下。（本条 3.0 秒，让落日完整走完。）
- **运镜**：`Arc` 以三人为中心弧线环绕，角度不超过 30 度。
- **旁白**：山顶的落日，一天一场。
- **声音**：杯碟轻碰、人群低语（听不清内容）、远处的现场音乐被风削掉高频。
- **prompt**：`star-shaped glass library pavilion on a mountain top, the faceted glass shattering the setting sun into gold patterns, a family of three at the terrace railing — father with a cup, the twelve-year-old girl with both hands on the wooden rail leaning forward toward the sunset, mother half a step behind her, warm rim light on all three profiles, slow arc move`

#### S08 ｜ 19.50 – 22.00s ｜ 富龙小镇

- **画面**：黄昏的富龙四季小镇。19 栋彩色欧式建筑环着中心湖而建，湖面把建筑与红叶一起倒映，水色由亮金渐渐转为暗琥珀。市集摊位支起暖色串灯，人流在巷子里缓慢移动。镜头从市集近景升起，越过屋顶，露出整个山谷里的小镇轮廓与背后渐暗的山脊线。
- **运镜**：`Crane up` 垂直上升。
- **旁白**：（无）
- **声音**：市集人声、餐具声、一段现场木吉他；保持中远景距离感。
- **prompt**：`alpine-style town at dusk, 19 colourful European buildings ringing a central lake, reflections shifting from bright gold to dark amber, market stalls stringing up amber lights, pedestrians drifting through lanes, camera cranes up from street level to overlook the valley town, warm dusk light`

---

### 分镜 05 · 入夜 ｜ 22.00 – 28.00s ｜ 2 shots

**叙事任务**：把山野拉回人的尺度，再交给星空。

#### S09 ｜ 22.00 – 25.00s ｜ 阿那亚露台

- **画面**：阿那亚·崇礼的山谷露台，背后是极简的混凝土曲面音乐厅，与周围浓烈的暖色秋林形成强反差。**一家三口围在木桌旁**：三杯热饮，女儿那杯喝掉一半、杯口留着奶沫；一条灰格羊毛毯搭在她肩上、另一头垂到周宁腿上，她两手捧着杯子低头吹热气，一条腿曲起、脚踩在凳子的横杆上。热气被风拉成一道斜线。（本条 3.0 秒。）
- **运镜**：`Orbit` 绕木桌极慢环绕。
- **旁白**：（无）
- **声音**：杯碟轻碰、毛毯摩擦、女儿小声说话；配乐在此降到最薄。
- **prompt**：`autumn outdoor picnic on a valley terrace, minimal curved concrete concert hall behind, family of three around a wooden table, the twelve-year-old girl with a grey plaid wool blanket over her shoulders holding a mug with both hands, head bowed blowing on the steam, one knee drawn up with her foot on the stool rail, steam pulled sideways by wind, very slow orbit move, warm intimate tone`

#### S10 ｜ 25.00 – 28.00s ｜ 喜鹊梁星空

- **画面**：入夜的山脊。几乎没有光污染，银河干净地横贯画面，星点密到发白。前景是山脊的暗轮廓与几支白桦枝梢，成排风机的剪影立在天际线上，叶片还在极慢地转。远处山谷里只有小镇的一点灯。**与 S06 同地不同时，形成黄昏与深夜的呼应。**（本条 3.0 秒，配乐推到最厚。）
- **运镜**：`Tilt up` 仰摇上升，从山脊摇到星空，速度极慢。
- **旁白**：（无）
- **声音**：夜风、远处小镇的极低底噪。
- **prompt**：`extremely low light pollution night sky over a mountain ridge, milky way spanning the frame, silhouette of ridge, birch tips and a row of wind turbines in the foreground, one cluster of faint town lights far below, camera tilts up slowly from ridge to stars, deep blue night`

---

### 分镜 06 · 收束 ｜ 28.00 – 30.00s ｜ 1 shot

**叙事任务**：信息与落版一次给完，收片。

#### S11 ｜ 28.00 – 30.00s ｜ 攻略插卡（海报版式）

- **画面**：全片唯一的信息图形画面，**直接用横版海报的版式**（见第 06 节）。左栏深色文字区：眉标、主标题「北京 → 崇礼」、副标题「崇礼，不止一场雪」、三条信息（高铁约 1 小时 / 自驾约 200 公里 / 0–14℃）；右栏是山间公路穿过秋林的大图，两栏之间用水平渐变融合。三条信息随旁白依次亮起，其余保持灰阶等待。
- **运镜**：`Push in`（极缓）几乎察觉不到的推进。**只给 2.0 秒，是全片最短的一镜**——海报上的大数值必须一眼可读，所以不加任何入场动画，淡入即满屏。
- **旁白**：崇礼，不止一场雪。
- **声音**：音乐收束到一个单音，留 0.8 秒余韵。
- **prompt**：`dark minimal travel poster, left column of warm near-black with oversized type "Beijing to Chongli" and three info rows each with a line icon and one large numeral, right column a winding mountain road through golden autumn forest, horizontal gradient blending the two columns, warm amber and russet accents, rows lighting up sequentially, 16:9`

> **这一镜身兼两职**：既是全片唯一的出行信息画面，也是落版。海报自带主标题与 slogan，所以原来的落版镜（山脊剪影 + 大字）已删除，全片由 12 shots 收敛为 11 shots。
>
> 如果之后觉得 2 秒不够读，可以拉回 3 秒——代价是总时长变成 31 秒，需要从 S02/S04/S05 里各减 0.3 秒找平。

### 景点角标（右上角地名）

**每个风景 shot 的右上角叠印景点名**，让观众始终知道自己站在哪里。这是本片唯一允许叠在实拍画面上的文字（S11 是信息图，另行处理）。

| shot | 角标文字 |
|---|---|
| S01 | 京张高铁 · 北京 → 崇礼 |
| S02 | 梧桐大道 · 太子城 |
| S03 | 太舞滑雪小镇 |
| S04 | 玉石梁 · 2160 米 |
| S05 | 翠云山白桦林 |
| S06 | 喜鹊梁 · 2078 米 |
| S07 | 翠云山 · 星芒图书馆 |
| S08 | 富龙四季小镇 |
| S09 | 阿那亚 · 崇礼 |
| S10 | 喜鹊梁 · 夜 |

S11（海报）**不加角标**：海报本身就是信息图，画面里已有「北京 → 崇礼」，再叠一层地名会打架。

**视觉规格**（按实际画面比例，不锁定基准尺寸）

| 项 | 规格 |
|---|---|
| 位置 | 右上角，右对齐于距右边 **5% 画面宽**，基线距顶边 **5% 画面高** |
| 字号 | **画面宽度的 3.4%**，字重 500，字距 +0.06em |
| 颜色 | 暖白 `#F2E9DC` |
| 装饰 | 文字下方一条等宽极细金线（约字号的 2% 高度），不透明度 50% |
| 动效 | 切入后 0.15s 淡入、0.2s 完成；不做淡出，随硬切带走 |

> 全部按比例给出，不写死像素——实际分辨率由生成设备决定（1K 起步、主景 2K），改设备随时等比换算，稿子不用动。

**两条纪律**

1. **角标不是字幕，别做成条幅。** 不加半透明底框、不加描边、不用衬线体——一旦做成"角标条"，广告味立刻出来。
2. **字数上限 14 字符**，超了就砍。2.5 秒的镜头里观众最多读一行短句。

---

## 05 角色设定 · 单独成像卡

全片只有 **3 个角色——父亲陆行、母亲周宁、12 岁女儿夏夏**。三个人先各自单独出一张标准形象图并锁死，再进分镜生成。三张脸在连切时各带一个独立的**暖调微色偏**，并且明度成一档阶梯（父亲最暗 → 母亲中间 → 女儿最亮），避免在全片统一的暖色里糊成同一个人。全员秋装，不需要任何雪具。

### ROLE A ｜ 陆行（父亲）

- **定位**：男 · 36 岁 · 中青年父亲 · 旁白的声音就是他
- **气质**：稳，但不沉。不是板着脸的父亲——女儿一开口他就停下来听，笑起来眼角先动。全片他只在两处真正放松：看女儿骑车时，和看落日时。
- **面部**：轮廓干净但不锋利，眉形平直，眼睛亮而有神。笑起来眼尾先动、出现两道浅纹；不笑的时候也不显得严肃。肤色健康偏暖，下巴刮得很干净、留一层淡青的胡茬印。头发短而利落。
- **体态**：身形挺拔匀称（约 1.78 米），肩膀平直不厚重。走路步幅大、节奏快，站着习惯把重心放在一侧，手插在风衣口袋里。
- **服装**：深驼色薄风衣，内搭浅灰圆领针织；深灰围巾随手搭着、不围紧。手腕一只深色钢带运动手表。
- **出场**：S01、S04、S06、S07、S09
- **微色偏**：`warm grey-brown`（三人中最暗的一档，只作明度基底，不承载年龄感）
- **成像 prompt**：`36-year-old chinese man, clean but not sharp facial contours, straight brows, bright attentive eyes, two fine lines at the outer corners when smiling, warm healthy skin tone, neatly shaved with a faint stubble shadow on the chin, short well-kept hair, dark camel light trench coat over a light grey crew-neck knit, dark grey scarf worn loose, dark steel sports watch, warm grey-brown grade, warm autumn key light, energetic young father portrait, standard reference, plain background`

### ROLE B ｜ 周宁（母亲）

- **定位**：女 · 34 岁 · 母亲 · 全片的情绪中枢
- **气质**：松弛、明亮。她不抢镜，但每一张有她的画面都会变软——她是那个一直在把别人吹乱的头发别到耳后、把毯子掖好的人。
- **面部**：圆润脸型，眼睛偏大，笑的时候眼角有细纹、苹果肌鼓起；颧骨处有被山风吹出的自然红，皮肤在暖光下是暖象牙色。
- **体态**：身形纤细（约 1.65 米），头发随手挽成一个低发髻，几缕碎发贴在颈侧；动作轻，站着习惯把重心放在一条腿上。
- **服装**：米白色粗针织外套，驼色披肩，深色长裤；露台段落裹一条灰格羊毛毯。
- **出场**：S01、S04、S05、S07、S09
- **微色偏**：`warm ivory`（中间明度，偏亮的暖调）
- **成像 prompt**：`34-year-old chinese woman, round-soft face, large eyes with fine crow's feet when smiling, full cheeks with a warm flush from mountain air, slim build, loose low bun with a few strands on the neck, cream chunky knit cardigan, camel shawl, warm ivory grade, warm autumn sidelight, gentle mother portrait, standard reference, plain background`

### ROLE C ｜ 夏夏（女儿）

- **定位**：女 · 12 岁 · 全片的情绪落点 · 大名叫陆知夏
- **气质**：开始有少年气——不再是被牵着手走的小孩，也还没学会装大人。好奇心还在，只是表达变安静了：话少，眼睛先动。全片她最放得开的一刻，就是在白桦林里接住那片落叶的瞬间。
- **面部**：婴儿肥已经退干净，脸型收成清瘦的鹅蛋，下颌线清楚；眼型偏细长、眼神定，睫毛长。鼻梁挺起来一点，笑起来嘴角多半只抬一侧。齐肩发扎成利落的高马尾，额前留几缕碎发。
- **体态**：个子明显抽条（约 1.55 米，到母亲眉眼的水平），手脚细长，站姿不再往大人身上靠；动作干净、步幅大，没有幼儿式的张开手臂。
- **服装**：姜黄色冲锋衣，**红围巾**（全片唯一的赭红点睛，也是三人里最跳的一件），深灰运动长裤，运动鞋。米色针织帽，戴得随意，有时干脆只挂在背包带上。
- **出场**：S01、S04、S05、S06、S07、S09
- **微色偏**：`warm peach`（三人中最暖最亮的一档；饱和度刻意收住——12 岁的皮肤不该是一片粉）
- **成像 prompt**：`12-year-old chinese girl, slim oval face with a clear jawline and no baby roundness, narrow bright eyes with long lashes and a steady gaze, light natural flush on the cheeks, high ponytail with a few loose strands at the temples, ginger-yellow windbreaker, red scarf, dark grey sports trousers, sneakers, beige knit hat worn casually, warm peach grade with restrained saturation, warm autumn backlight, poised twelve-year-old, full body standard reference, plain background`

---

## 06 片中插卡（S11 那一帧）

**末镜直接用横版海报的版式与设计作为插卡。** 插卡素材只有一个文件，身兼信息画面与落版两职。

**版式**

| 区域 | 内容 |
|---|---|
| 左栏 980px | 深色暖黑文字区 |
| 右栏 940px | 山间公路穿过秋林（盘山公路，纵深向远方收） |
| 过渡 | 两栏之间用水平渐变融合，不做硬切 |

**左栏内容与字号**

| 元素 | 字号 |
|---|---|
| 眉标「国庆初秋 · 10.01」 | 40px |
| 主标题「北京 → 崇礼」 | 96px |
| 副标题「崇礼，不止一场雪」 | 44px |
| 大数值 | 76px |
| 说明行 | 42px |
| 底部「赏叶最佳期 9 月下旬 — 10 月下旬」 | 42px |

**三条信息**

| 列 | 大数值 | 说明 |
|---|---|---|
| 高铁 | **约 1 小时** | 清河站 → 太子城站 · 出站免费接驳 |
| 自驾 | **约 200 公里** | 京礼高速 S3801 · 崇礼北出口 · 约 3 小时 |
| 天气 | **0 – 14℃** | 初秋昼夜温差大 · 山顶记得带外套 |

**文件**

- 矢量源：`chongli-travel-poster.html`
- 成品图：`chongli-travel-poster.png`（3840×2160）
- 底图：`assets/bg-road.png`（山间公路；换图即换风格，版式不用动）
- 分辨率：矢量源 1920×1080、导出 3840×2160，进 1K / 2K 成片时**等比缩小即可**（向下缩放不掉质感，切勿反过来放大）

> **只给 2 秒的两点处理**
>
> ① 侧栏文字里，「崇礼，不止一场雪」是 slogan、「赏叶最佳期」是补充信息，观众在 2 秒内实际只能抓住三个大数值。这是可以接受的——大数值是给人读的，其余是氛围。
> ② 不加任何入场动画：淡入即满屏，不要逐行点亮。逐行点亮按 0.5 秒一行算，第 3 行亮起时镜头已经切走了。

> 分段规则：一行里出现两个信息时统一用「·」分隔，例如「清河站 → 太子城站 · 出站免费接驳」。全角空格在大字号下会把两段读成一句，而且比「·」更宽、容易越界。

---

## 07 声音

"精美"有一半来自声音，而"昂贵"来自安静。旁白只有 14.1 秒，其余 15.9 秒全部交给音效与配乐。

**配乐**

- 基调为**暖木吉他 + 钢琴 + 一层温暖弦乐垫底**，与画面的初秋暖调同频
- 调性走大调或明亮的自然小调；乐器只用原声，不用电子音色
- S03 缆车上升时进入，72–80 BPM，不用鼓点
- S08 小镇与 S09 露台处降到最薄
- S10 星空推到最厚，S11 收成单音后留 0.8 秒余韵

**音效清单**

| 位置 | 音效 |
|---|---|
| S02 | 落叶被碾碎的脆响（全片的"秋天味"全在这一条） |
| S03、S05 | 白桦叶被风掀动的哗啦声 |
| S06 | 两辆自行车的链条声 + 车铃 + 风机低频 |
| S07、S09 | 杯碟轻碰、毛毯摩擦 |
| S08 | 市集人声与现场木吉他，保持中远景距离 |

**旁白混音**：人声置前，配乐在 1.5–3kHz 侧链避让；句间气口不剪死，保留 0.4–0.6 秒；整体响度 -16 LUFS。

**禁止事项**：不用"大片感"锣鼓、不用电子 drop；不加笑声、不加人声合唱；不用素材库里的假风声；**全片不允许出现任何雪的痕迹**。

---

## 08 三条硬约束

1. **一条 prompt 只写一个 camera motion** — 模型最容易把"推"和"摇"叠在一起，结果画面来回飘。每条 shot 的 prompt 里只保留一个运动动词。
2. **暖要来自光，不来自后期** — 在 prompt 里把光写暖，而不是生成完再套暖色 LUT。套出来的暖会让皮肤发橙、叶子变成塑料黄。检验方法：把画面转黑白，明暗层次还立得住才算过关。
3. **全片不能出现雪** — 这是最容易翻车的一条。prompt 里任何 snow / winter / ski / snowfall 词都不能出现；缆车要写站台和轿厢，不要写雪道。落版句"不止一场雪"是文字层面的双关，不靠画面兑现。

---

*崇礼国庆初秋短片 · Storyboard v3.8 · AI 生成版*
*6 个分镜 / 11 shots / 30.00s / 覆盖景点 9 个 / 一家三口 / 男声旁白 5 句 45 字 · 口播 14.1s · 留白 15.9s / 末镜海报收尾*
