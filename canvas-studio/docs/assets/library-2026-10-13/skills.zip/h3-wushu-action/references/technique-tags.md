# 武打 LoRA 招式 TAG 完整清单（V7 训练集全量提取）

> 提取范围：924 条训练 caption（中英双语全文穷举，含引号/括号内标注术语）
> 频次 = 该词在训练集中出现次数，**频次越高，LoRA 对该招式的响应越强、越稳定**
> 使用建议：优先用高频词；低频词（≥3 次）仍有效但需要配合更多上下文描述

---

## 一、腿法 TAG

| TAG | 频次 | 说明 |
|---|---|---|
| 扫堂腿 | 47 | 训练集第一腿法，响应最强 |
| 腾空侧踹 | 17 | 常与扫堂腿组成连招 |
| 后旋踢 | 16 | 腾空后旋踢变体常见 |
| 鞭腿 | 7 | 高位弧线 |
| 旋风脚 / 腾空旋风脚 | 14 | 转体+腾空复合 |
| 双飞脚 | 3 | |
| 正蹬 / 侧踹 | 各 3 | |
| 踢击 | 10 | 泛用兜底词 |

## 二、拳法 TAG

| TAG | 频次 | 说明 |
|---|---|---|
| 直拳 | 12 | 右直拳最常见 |
| 崩拳 | 3 | |
| 贯耳捶 | 2 | |
| 拳法连击 / 组合拳 | 5+ | 泛用 |

## 三、掌法 / 肘膝 / 靠法 TAG

| TAG | 频次 | 说明 |
|---|---|---|
| 贴山靠 | 12 | 肩靠标志性招式，响应强 |
| 肘击 | 5 | |
| 推掌 / 双推掌 | 4 | |
| 拍掌 / 横掌 | 2 | |

## 四、摔法 / 擒拿 TAG

| TAG | 频次 | 说明 |
|---|---|---|
| 过肩摔 | 17 | 高频，双方戏常见 |
| 擒拿 | 12 | 锁腕/锁肘变体多 |
| 接腿摔 | 3 | |
| 大背摔 | 2 | |

## 五、格挡 / 身法 / 攻防衔接 TAG（训练集最高频类，决定动作流畅度）

| TAG | 频次 | 说明 |
|---|---|---|
| **格挡卸力**（ge dang xie li） | **74+** | **全场第一词** |
| 闪身（shanshen） | 14 | |
| 上架格挡 | 12 | |
| 横扫卸力 | 5 | |
| 借力打力 | 8 | |
| 以攻代守 | 8 | |
| 攻防转换 | 15+ | |
| 连击 / 连招 | 5+ | |
| 压迫 / 逼退 | 5+ | |

## 六、器械-剑术 TAG

| TAG | 频次 | 说明 |
|---|---|---|
| 缠头裹脑（chan tou guo nao） | 54 | 剑/刀通用的招牌起手 |
| 回马枪式反手撩 | 10 | 剑枪通用 |
| 劈剑 | 9 | |
| 撩剑（liao jian） | 8 | |
| 云剑 | 3 | |
| 点剑 | 3 | |
| 剑气 | 3 | |

## 七、器械-枪棍 TAG

| TAG | 频次 | 说明 |
|---|---|---|
| 红缨枪 | 16 | 主体名词 |
| 扎枪（zha qiang） | 12 | |
| 横扫（heng sao） | 12 | 棍/枪通用 |
| 拦拿（lan / na） | 9 | |
| 中平枪 | 6 | |

## 八、器械-刀术 TAG

| TAG | 频次 |
|---|---|
| 大刀劈砍 | 5 |
| 缠头刀 / 裹脑刀 | 4 |
| 过顶举刀蓄力劈 | 4 |
| 双刀交叉格挡 | 3 |

## 九、步法 / 桩功 TAG（放 Shot 1 / Shot 3，显著提升专业感）

| TAG | 频次 |
|---|---|
| 弓步（gongbu / bow stance） | 38 |
| 马步（mabu / horse stance） | 29 |
| 点步（dianbu） | 13 |
| 进退步法 | 11 |
| 垫步 | 9 |
| 虚步（xubu / empty stance） | 7 |
| 半马步 | 7 |
| 进步（jinbu / advancing step） | 7 |
| 侧身步 | 5 |

## 十、腾空 / 翻滚 / 身法 TAG

| TAG | 频次 |
|---|---|
| 腾空 | 32 |
| 纵跃 | 18 |
| 旋身横扫 | 17 |
| 下潜 | 11 |
| 翻滚 | 10 |
| 空中转体 | 10 |
| 后仰 | 10 |
| 滚翻卸力 | 6 |
| 蹬墙借力 | 3 |

## 十一、发力描述 TAG（训练集句式，提升动作质感）

| TAG | 频次 | 用法 |
|---|---|---|
| 拧腰 | 32 | "拧腰送胯" |
| 沉肩坠肘 | 24 | 起手式描述 |
| 屈膝 | 21 | |
| 顺势 | 18 | |
| 转腰 | 14 | |
| 腰胯发力 | 14 | "以腰胯发力" |
| 躯干拧转 | 14 | |
| 压向前 | 14 | "重心压向前脚" |
| 蓄力 | 13 | |
| 蹬地 | 12 | |

## 十二、重心 / 步法过渡句式 TAG（Shot 间衔接）

| TAG | 频次 |
|---|---|
| 重心移至后腿 | 19+ |
| 重心压向前脚 | 14+ |
| 支撑腿 | 14 |
| 脚过渡到前脚 | 12 |
| 前腿 / 后腿 | 9+ |

## 十三、英文 / 拼音 TAG 对照（caption 可直接混用）

| 拼音 / 英文 | 对应中文 | 频次 |
|---|---|---|
| sao tang tui / horizontal sweep | 扫堂腿 | 10 |
| chan tou guo nao | 缠头裹脑 | 20 |
| ge dang xie li | 格挡卸力 | 15 |
| shanshen | 闪身 | 14 |
| gongbu / bow stance | 弓步 | 27+ |
| mabu / horse stance | 马步 | 17+ |
| dianbu | 点步 | 13 |
| zha qiang | 扎枪 | 12 |
| tie shan kao | 贴山靠 | 12 |
| liao jian | 撩剑 | 8 |
| xubu / empty stance | 虚步 | 7 |
| jinbu / advancing step | 进步 | 7 |
| zhi quan | 直拳 | 9 |
| teng kong xuan feng jiao | 腾空旋风脚 | 5 |

## 十四、场景 / 镜头 TAG（辅助，非招式）

- **镜头**：Wide shot / Full shot / Medium shot / Medium-long shot / Close-up / fixed camera / side angle / low-angle / tracking shot / handheld follow / three-quarter view
- **场景**：traditional courtyard / bamboo grove / snowy courtyard / white-wall studio / motion-capture studio / industrial stage / ruined city / boxing ring / wooden stage / concrete bridge
- **主体**：red-robed swordsman / dark-armored warrior / female martial artist / twin hook swords / heavy saber / straight jian / red tassel spear（红缨枪 ×16）

## 十五、音效 TAG（`overall_soundscape` 句式元素）

- **兵刃破空**：blade whoosh / sword whistle / shaft cutting air
- **身体**：cloth friction / fabric snapping / heavy breathing
- **脚步**：footsteps scraping / scuffing / footwork thuds
- **接触**：dull impact / metal clash / punch impact / ground scrape
- **环境**：outdoor ambience / bamboo leaves / street ambience

---

## 附：低频词使用提示

- 频次 1–2 的词（如蹬墙借力、双飞脚、大背摔）**可用但响应弱**，建议配一句完整上下文描述。
- 训练集 caption 句式优先级：**具体招式 > 发力描述 > 攻防衔接 > 泛动作词**。
- 组合公式：`[Shot N] = 蹬地/拧腰（发力）+ 招式术语（主体）+ 格挡卸力/顺势（衔接）`
