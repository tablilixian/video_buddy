# 运镜术语与语法

---

## 一、⚠️ 两套写法不要混用

H3 有**两套运镜写法**，用哪套取决于**挂不挂 Camera Motion LoRA**：

| | 挂 LoRA | 不挂 LoRA（官方 API / T2VA 直出） |
|---|---|---|
| **写法** | **逗号标签式** | **自然语言融入句子** |
| 示例 | `camera motion, [主体], [场景], slow push-in with slight orbit, ...` | `The camera pushes in with small amplitude at slow speed toward the folded letter in her hands.` |
| 原因 | LoRA 是照**训练素材的标注格式**训的，标签式命中率最高 | H3 原生更懂自然语言描述 |

**判断方法**：prompt 开头有没有 `camera motion`。有 → 标签式；没有 → 自然语言法。

**混用的后果**：挂 LoRA 却写自然语言长句，运镜控制会失效或半失效；不挂 LoRA 却堆逗号标签，模型会当成场景描述的一部分，镜头不动。

---

## 二、镜头运动的三个维度

完整的运镜表达包含三维度：

| 维度 | 说明 |
|---|---|
| **运动类型** | 镜头如何移动 |
| **幅度** | 构图变化的范围 |
| **速度** | 变化的节奏 |

**中等幅度与正常速度通常省略不写**——只在有意义时才加。

---

## 三、运动类型速查表

| 类型 | 英文表达 | 说明 |
|---|---|---|
| 推镜 | `Push In` | 镜头向前移动 |
| 拉镜 | `Pull Out` | 镜头向后移动 |
| 变焦推进 | `Zoom In` | 焦距变化，机身静止 |
| 变焦拉远 | `Zoom Out` | 焦距变化，机身静止 |
| 左摇 | `Pan Left` | 镜头原地水平旋转（左） |
| 右摇 | `Pan Right` | 镜头原地水平旋转（右） |
| 左移 | `Truck Left` | 镜头水平平移（左） |
| 右移 | `Truck Right` | 镜头水平平移（右） |
| 上仰 | `Tilt Up` | 镜头原地垂直旋转（上） |
| 下俯 | `Tilt Down` | 镜头原地垂直旋转（下） |
| 上升 | `Pedestal Up` | 整个镜头上升 |
| 下降 | `Pedestal Down` | 整个镜头下降 |
| 环绕 | `Arc Shot` | 镜头绕主体弧形移动 |
| 跟踪 | `Tracking Shot` | 镜头跟随移动的主体 |
| 固定 | `Static Shot` | 镜头位置与焦距保持静止 |
| 轻微震动 | `Shake Slightly` | 轻微镜头震动 |
| 强烈震动 | `Shake Strongly` | 强烈镜头震动 |
| 主观视角 | `POV` | 主体的第一人称视角 |
| 顺时针旋转 | `Roll Clockwise` | 镜头绕光轴顺时针旋转 |
| 逆时针旋转 | `Roll Counterclockwise` | 镜头绕光轴逆时针旋转 |

---

## 四、幅度与速度

**幅度**（中等通常省略）：

| 幅度 | 英文表达 |
|---|---|
| 小幅度 | `with small amplitude` |
| 大幅度 | `with large amplitude` |

**速度**（正常通常省略）：

| 速度 | 英文表达 |
|---|---|
| 慢速 | `at slow speed` / `slow` |
| 快速 | `at fast speed` / `aggressive` / `dynamic` |

---

## 五、自然语言融入法（不挂 LoRA 时用）

**原则：写成自然的英语动作，融入当前镜头描述中，而不是在句尾堆砌标签。**

✅ 推荐：

```
The camera pushes in with small amplitude at slow speed toward the folded letter
in her hands.
```

❌ 避免：

```
The camera pushes in, slow, small amplitude.
```

---

## 六、复合运镜句式（挂 LoRA 时用）

复合运镜**必须是时间上有先后的连续运动**，不是多个方向同时作用：

| 关系 | 句式 | 示例 |
|---|---|---|
| **顺序** | `A then B` | `slow push-in to close-up then dramatic pull-back to wide reveal` |
| **过渡** | `A transitioning to B` | `slow push-in to medium shot transitioning to slight pull-back` |
| **结合** | `A combined with B` | `slow pull-back combined with gentle orbit around the fighters` |
| **主 + 微** | `A with slight B` | `slow push-in with slight orbit around the fighters` |
| **跟随关系** | `A following B` | `dynamic handheld camera with slight push-in following the action` |
| **揭示目的** | `A revealing B` | `slow pull-back ... revealing the full scale of the environment` |

---

## 七、动作场面里的运镜纪律

| 纪律 | 说明 |
|---|---|
| **一个镜头只用一种主运镜** | 同时写环绕 + 推拉 + 手持抖动必崩，这是最常见的翻车原因 |
| **手持跟拍 = 跟随，不是抖动** | 写清跟随对象与随动方式：`following the action` / `tracking sideways as they cross` |
| **镜头太紧会削掉动作幅度** | 大幅动作戏要加 `swings wide enough to keep both bodies in frame`，否则模型压缩动作来适配画框 |
| **关键接触用固定或短促推近** | 持续环绕会掩盖打斗的接触点，决定性的一下要让它看得见 |
| **镜头要跟着主体走** | 镜头发呆（钉在原地）时，主体一走就出框，模型会自动把动作拉回原地——这是隐性"站桩"的成因 |

---

## 八、运镜与内容的匹配

| 内容 | 合适运镜 | 理由 |
|---|---|---|
| 建立空间、交代地理 | 航拍 / 拉远 / 升降 | 需要一次看清环境 |
| 对峙、紧张感累积 | 慢推近 / 环绕 | 压力递增 |
| 高速交锋 | 手持跟拍 / 横移跟拍 | 与动作同速 |
| 决定性一击 | 固定机位或短促推近特写 | 让接触看得清 |
| 动作收尾、余波 | 拉远 / 升降 | 拉开情绪距离 |
| 招式形状展示（演武） | 环绕 / 低角度跟拍 | 让招法被完整看见 |

---

## 九、排查速查

| 症状 | 首选修正 |
|---|---|
| 运镜完全没生效 | 检查是否写了触发电词 `camera motion` 且在句首；检查是否混用了两套写法 |
| 说了环绕给慢推 | 换库里的完整短语，别只写 `orbit` |
| 镜头乱抖 | 删到只剩一个主运镜 |
| 画面不稳 | LoRA 强度降到 0.8，确认不超过 1.2 |
| `pan` 不生效 | 摇镜是弱项，叠一个主运镜：`slow push-in with slight pan-right` |
| 主体出框 | 补跟随关系 + `swings wide enough to keep both bodies in frame` |
| 运镜压过主体 | 强度词降级（`aggressive` → `slow`），或换成更稳的运镜 |
