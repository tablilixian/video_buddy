# 官方成品模板（T1–T5）与结构规范

来源：`Jojocodex/wushu-action-v7-minimax-h3-fl2va-ref2va-lora` 模型卡 README。

---

## 一、结构规范

**规则**：以触发词 `wushu_action,` 开头；**角色外貌单独定义在「角色设定」块**（发色+服装+体型+兵器一次定义，全篇逐字固定），镜头里只称"角色 A / 角色 B"不重复外貌（人物一致性关键）；招式写具体术语（"扫堂腿" ✔ / "踢腿" ✘）；三段式分镜；结尾带音效描述。

### 模板格式（角色设定与镜头分离）

```text
wushu_action, 电影级硬核写实格斗。【场景+光线】。

角色设定：
角色A（攻方）：【性别+发色发型+服装+体型+兵器】
角色B（守方）：【性别+发色发型+服装+体型+兵器】

开局即战，攻防轮换，击中反馈分级，终结重击可击飞。

integrated_multimodal_description:
[Shot 1] 胸口手持跟拍。角色A【招式起势发力】，角色B【防守/受击反馈】。
[Shot 2] 短弧侧绕跟拍。角色B【反击】，角色A【防守】，双方换位。
[Shot 3] 急推近景。角色A【终结重击命中角色B】，角色B【沿作用线击飞+侧滚撞墙】，角色A【追击收势】。

overall_soundscape: 拳腿破空声、衣料剧烈摩擦声、格挡沉闷撞击声、重拳轰鸣命中声、急促喘息声。

non_diegetic_music:
None.
```

> **Ref2VA 下的映射**：`subject_definitions` = 官方的「角色设定」块；`<Subject N>` = 官方的「角色 A / 角色 B」。
> 官方要的是「定义一次、镜头里只称呼」，不要每镜复述外貌。

---

## 二、T1 扫堂腿 + 腾空侧踹（入门首选）

```text
wushu_action,

integrated_multimodal_description:
[Shot 1] Medium shot, side angle, outdoor courtyard with traditional architecture. A martial artist in a dark training uniform sinks into a low crouch, palms open at his ribs, weight loaded on the rear leg.
[Shot 2] He drives off the ground, sweeping low with a 扫堂腿 that scrapes dust off the floor, then springs airborne into a full-extension 腾空侧踹, heel leading, arms counter-swinging for balance.
[Shot 3] He lands rolling to dissipate force, rises into a front stance with palms pushed forward, holding the final guard.

overall_soundscape:
The whoosh of the sweeping leg, cloth friction, footwork scraping the floor, a dull impact on landing, controlled breathing.

non_diegetic_music:
None.
```

## 三、T2 长剑套路（缠头裹脑 + 回马枪）

```text
wushu_action,

integrated_multimodal_description:
[Shot 1] Wide tracking shot, bamboo grove at dusk. A white-robed swordsman holds a straight jian low, blade tip down, body turned sideways in a narrow stance.
[Shot 2] He opens with 缠头裹脑, the blade circling behind his neck and back, then snaps into a turning reverse thrust like a 回马枪, sword arcing close to the body before a rising 撩剑 flicks upward.
[Shot 3] He settles into a horse stance, sword extended point-forward, bamboo leaves drifting down around him.

overall_soundscape:
Sword blade cutting through air, cloth rustling, soft footsteps on fallen leaves, the ring of the blade settling.

non_diegetic_music:
None.
```

## 四、T3 双人对打（贴山靠 + 鞭腿）

```text
wushu_action,

integrated_multimodal_description:
[Shot 1] Medium shot, front angle, wooden stage. The red fighter initiates with a shoulder charge 贴山靠, the blue fighter angles sideways to deflect and unload the force 格挡卸力.
[Shot 2] Red presses in with an elbow strike, blue retreats half a step and counters with a whipping 鞭腿; red absorbs it on a hardened guard, both locked for a beat.
[Shot 3] They break apart simultaneously, stepping back into guarded stances, fists saluted, the exchange cleanly reset.

overall_soundscape:
Punch impacts, cloth rustle, footwork thuds on wooden planks, strained breathing, crowd murmur in the far background.

non_diegetic_music:
None.
```

## 五、T4 枪术回马枪

```text
wushu_action,

integrated_multimodal_description:
[Shot 1] Full shot, fixed camera, indoor white-wall studio. A spearman holds a vertical spear-holding ready stance, shaft planted, body angled.
[Shot 2] He slides into a charging thrust, then feints a retreat — at the turn he snaps the spear backward over his shoulder in a textbook 回马枪, the point whipping to full extension.
[Shot 3] He whirls the shaft overhead and slams the butt into the ground, settling into a bow stance, spear vertical.

overall_soundscape:
Wooden shaft whooshing through air, the shaft scraping against his palm, sharp foot slides, a heavy butt-end thud.

non_diegetic_music:
None.
```

## 六、T5 女子双钩剑（纯英文）

```text
wushu_action,

integrated_multimodal_description:
[Shot 1] Medium tracking shot, minimalist white room. A female martial artist in a yellow training robe holds twin hook swords inverted, blades hugging her forearms, weight coiled on the rear foot.
[Shot 2] She explodes forward, hooks sweeping in crossing arcs, then leaps into a full-rotation aerial spin, both blades extended in opposite directions, robe flaring with centrifugal force.
[Shot 3] She lands in a low horse stance, hooks crossed before her chest, holding the final pose as her sleeve settles.

overall_soundscape:
Twin blades whistling in counter-rotation, fabric snapping, a sharp landing thud, controlled breathing.

non_diegetic_music:
None.
```

---

## 七、可复用的收势写法（官方模板结尾范式）

官方五个模板的 Shot 3 全部是**"收势保持"**而不是"打完站着"，可以直接借用：

| 范式 | 原文 |
|---|---|
| 保持护架 | `holding the final guard` |
| 兵器定式 | `sword extended point-forward` / `spear vertical` |
| 桩步收 | `settling into a bow stance` / `a low horse stance` |
| 袖摆回落 | `holding the final pose as her sleeve settles` |

**注意**：这不是"静止站立"。它必须带**收势动作 + 余韵**（袖摆回落、兵器定线、呼吸、落叶），否则触发官方避坑清单第 3 条。
