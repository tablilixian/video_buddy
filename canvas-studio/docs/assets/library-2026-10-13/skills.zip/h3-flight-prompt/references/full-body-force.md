# 力量感与身体形变

**核心原则：力量写在身体上，不写在兵器上。**

打斗"软"的根本原因，几乎从来不是"打击力度不够"，而是**力量没有落在可观测的身体形变上**。火花、光效、金属轰鸣是漫画/游戏语言；实拍武打的力量感来自"**人被打得变形，而且起不来**"。

---

## 一、为什么不用碰撞特效

| 层面 | 理由 |
|---|---|
| **美学** | 火花、光效是**加法**，加在写实画面上立刻显假。真武打碰撞那一下是"闷"的——看不见光，只看见人被压弯 |
| **注意力** | 模型的总注意力有限。写 `sparks breaking off the ribs`，它就去生成粒子，**身体的受力形变会被简化**。写特效等于把预算从身体上挪走 |
| **H3 特有** | **粒子效果恰是 H3 的短板**。它的优势在身体运动力学——Wushu Action LoRA 的 924 段训练素材全是人体动作，**零特效素材**。让它生成火花容易得到噪点、闪烁、伪影。这是拿短板换长处 |

写法上：在 prompt 开头和结尾各写一次 `no sparks, no glow and no visual effects of any kind` 压制模型自己加戏。

---

## 二、身体形变词汇表

写力量时直接从这张表取词：

| 部位 | 力量表现 | 英文写法 |
|---|---|---|
| **脊柱** | 前折 · 后弓 · 被压圆 | `his spine folds forward over the blade` · `his back arches` · `his spine rounds over his own cut` |
| **膝盖** | 承重下沉 | `his rear knee sinks a hand's width into the stone` · `both knees bending deep under him` |
| **肩膀** | 被顶到耳边 · 耸高压起 | `his shoulders coming up around his ears` · `shoulders jammed high around his neck` |
| **前臂** | 被压回自己胸口 | `his arm is driven back against his own chest` |
| **躯干** | 被扭离基底 | `his torso is rotated off his base` |
| **重心** | 被压到脚跟 | `rocked back onto his heels` |
| **步型** | 被压缩 · 被迫变形 | `his stance compresses under him` · `standing a head lower than he was` |
| **头 / 下巴** | 被顶起、偏离中线 | `his chin is driven up off line` |
| **恢复** | **直不起身** | `neither of them able to straighten` · `neither man straightens up out of it` |
| **呼吸** | 被顶出一口气 | `breath driven out hard through the teeth` |

**两条最好用的：**

1. **`shoulders coming up around his ears`（肩膀被顶到耳边）** —— 人承受上方压力时肩膀会本能耸起，画面里极其明确，模型也好生成。
2. **`neither of them able to straighten`（没能直起身）** —— **力量感的终极表达**。它同时说明三件事：力量多大、身体在承受、承受还在持续。

> **力量大的标志不是响声大，而是身体来不及恢复。**

---

## 三、整劲：力量从地面传到兵器末端

只写手臂动作必然软。**力量必须有一条完整的传导链。**

**① 链条写全：**

```
power comes up from the ground through the feet, legs, hips, back, shoulders and
arm into the weapon
```

**② 「胯、肩、刃同时到位」** —— 把"身体跟随动作"变成可观测的同步事件：

```
hips, shoulders and blade arriving together
```

**③ 脚步必须随招式重排**（同时是防崩关键，见 `references/footwork-and-space.md`）。

**④ 用整身动词，不用"移动"：** `uncoiling upward off both legs`（从双腿向上解绕）· `feet crossing through into a new stance`（脚下交叉换步）· `his whole body turning over behind it`（整个身体在它背后翻转）。

---

## 四、气劲：只能写在这四个地方

**气劲不是特效，是环境对招式的反应。** 但它**必须服从物理**——兵器不是风扇。

### ⚠️ 先记住兵器做不到什么

| 错误写法 | 为什么不成立 |
|---|---|
| 兵器挥动**卷起地面落叶 / 大范围扬尘** | **刃是一块极薄极小的面**，挥动产生的气流只在刃口附近有效，不足以扬起地面物体 |
| **下劈把落叶向外翻** | 气流方向**向下**，物理上应把叶子**压住**——这个最容易写反 |
| **旋转招式卷起螺旋气流卷叶绕身** | 人体旋转的涡流远不足以卷起落叶 |
| "一带落叶成扇面飞散" / "气墙" | 规模明显过大 |

**掌风能带起尘叶，剑风不能。** 掌面大、推空气效率高；剑刃的迎风面积几乎为零。

### 能扰动环境的四个来源（按可靠度排序）

| 来源 | 可写的形式 | 可靠度 |
|---|---|---|
| **① 脚步** | 蹬地扬尘 · 急停滑痕 · 碾转蹭砂 · **脚踢散落叶** | 最可靠（唯一直接作用于地面的部位） |
| **② 衣袂** | 衣袖被手臂驱动甩起绷紧 · 衣摆随转体荡开 | 可靠（附着于身体，被动跟随） |
| **③ 接触点** | 两件兵器相撞压缩空气，一次**短促平推**（范围≈兵器本身宽度） | 可靠（规模必须小） |
| **④ 刃口划过空气** | 一道**细而短促**的扰动尾迹，**离刃一掌内消散** | 只能留痕 |

**落叶的正确用法：走位证据，不是气劲介质。** 叶子静卧在地，**只有脚步扰动它们**——被踩散、被踢开、被碾过。场景句里写死这一点：

```
the leaves lie settled on the stone and only the feet disturb them
```

这一句是**物理声明**，它同时封掉了"兵器气劲卷叶"的写法。

### 铁律：气劲句要有介质，且介质必须与来源匹配

**判断标准两条**：① 它作用在什么上面？② **施力的那个部位，有没有能力造成这个规模？**

| ❌ 物理错误 | ✅ 物理正确 |
|---|---|
| `leaves and grit lift and fan outward from the line of the cut` | `his front foot stamping down and the grit jumping under it` |
| `the downstroke pushes a visible wedge of air into the stone floor` | `his rear foot grinding a half turn out of the grit under it` |
| `the turn drags a spiral of air around him and the leaves circle with it` | `his jacket hem swinging wide off the turn` |
| `his qi flares` / `a burst of energy from the blade` | `the edge trailing a thin wake of disturbed air that fades within a hand's width` |

**介质与来源的对应关系：**

| 介质 | 只能由谁驱动 |
|---|---|
| 砂砾、尘土 | **脚**（蹬、碾、滑、踢） |
| 落叶 | **脚**（踩、踢、滑） |
| 衣袖、衣摆 | **手臂与躯干** |
| 空气扰动 | **刃口**（细尾迹）· **接触点**（短促平推） |

**跨来源使用就是物理错误**——兵器驱动落叶、转体卷起气流，都不成立。

### 三条纪律

1. **气劲是余韵，不是主力。** 力量的主力永远是**身体形变**（脊柱 / 膝盖 / 肩膀 / 直不起身）。顺序固定：**先身体受力，后气劲**。
2. **规模要有上限。** 刃口尾迹＝离刃一掌；接触气流＝兵器宽度；扬尘＝脚下。
3. **衣袖是最划算的介质。** `his robe snapping out behind the drive of the swing` —— 一个短句同时暗示力量与速度，且物理完全成立（衣服附着在身体上）。

---

## 五、受击分级递进（防单调）

同一套身体反应写四遍会看腻。让强度爬升：

| 等级 | 身体表现 |
|---|---|
| **中** | 脊柱前折、膝盖下沉、被压到脚跟，**但还能撑住** |
| **中高** | 脊柱弓起、肩膀耸到脖子、脚下碾转半圈，**靠意志不退步** |
| **极高** | 脊柱弯圆、双膝深弯、总重量压进地面、**双臂抖动、直不起身** |
| **高（收尾）** | 转身被撞停、重心砸进前腿，**仍然折着** |

**「还能撑住 → 靠意志不退 → 直不起身 → 仍然折着」** —— 这条递进本身就是力量的叙事。观众不需要看火花，他已经知道这几下有多重。

**关键：折身之后不要重新站好。** 写成保持折身进下一招（`both men stay folded`、`still folded into the impact`），否则会退回回合制。

---

## 六、硬防守：防守也是发力

**每一次接触都是一次力量碰撞——不论它来自双方同攻，还是来自一方攻、一方硬接。**

**软防守（禁止）：**

| 被动动词 | 问题 |
|---|---|
| `blocks the thrust` | 挡住，无事发生 |
| `deflects the blade aside` | 拨开，力量被卸掉 |
| `slips it` | 闪开，接触消失 |
| `steps back out of range` | 退开，重新开始 |

**硬防守（要写）：**

| 写法 | 含义 |
|---|---|
| `braces and takes the thrust head-on on the fan ribs` | 迎上去用扇骨硬吃 |
| `steps into it and drives the fan face down to meet the blade` | 迎上去（甚至前压） |
| `jams the fan up horizontally to meet it` | 横架迎击 |
| `his weight stays forward and he does not take the step` | 不退缩（但可以横移，见走位文件） |

**防守方的力量证据必须写全，且「受力」与「坚持」两者都要有：**

```
his rear foot gouges half a turn through wet grit, dust spraying off it, but he
holds his ground with his shoulders jammed high
```

先写被推得后脚碾地半圈（**真实受力**），再写他没退（**对抗意志**）。

> 只有受力没有坚持，防守就是被压垮；只有坚持没有受力，防守就是无敌。**两者都要有，才是力量碰撞。**

**注意「不退让」≠「不移动」**：`holds his ground` 表达的是不放弃对抗，**不是钉在原地**。
防守时的正确形态是**横向移动、绕圈、斜切**——都在"不退让"范围内，但人是动的。
被大力推时会有真后退，但**后退之后立刻侧切绕开重新找角度，不是站定**。
写法见 `references/footwork-and-space.md` 第二节。

---

## 七、借力变招：防守后的桥梁

防守不能只守住，要把**对方的力量变成自己下一招的起势**：

```
he does not give ground -- he takes the flick on the ribs and rides that pressure
straight into his own entry, using the force he just absorbed to open the line he
needs
```

**防守动作和进攻动作在物理上是同一个连续动作**——对方推来的力，就是他下一招的助力。三个好处：零间隙、力量有来处、观众看得懂"借力反转"。

技术上对口：**Combat Base V2 模型卡原话「格挡可自然顺势变向」**（`blocks change direction smoothly`），它是 H3 生态里唯一原生支持"防守后变招"的 LoRA。

---

## 八、排查表

| 症状 | 原因 | 改法 |
|---|---|---|
| 力量感不够，画面"轻" | 力量没落在身体上 | 每次接触补身体形变：脊柱 / 膝盖 / 肩膀 / 步型 |
| 人被打到但看着没事 | 缺"恢复不过来" | 补 `neither of them straightens up out of it` |
| 有撞击但没冲击感 | 镜头没吃力 | 补 `one hard frame of kick on each stop`（只在相撞那帧震，立刻回位；持续抖动是业余感） |
| 声音脆而薄 | 缺低频 | 加 `flat knock` + **声音的尾巴**（`grit pattering down after it`） |
| 整体还是软 | 环境完全不动 | 加撞墙/撞柱、扬尘、落叶——**环境不动，力量就没有出口** |
| 出现了火花/光效 | 模型自己加戏 | 首尾各写一次 `no sparks, no glow and no visual effects of any kind` |
| **落叶被兵器挥动卷起**（物理错误） | 跨来源使用了介质 | 落叶只由**脚**驱动；兵器气劲只留刃口细尾迹 |
| **下劈把叶子吹向外**（方向写反） | 气流方向写错 | 下劈不写叶片动效；要写就写脚下砂跳 |
| **转身卷起螺旋气流** | 物理不成立 | 改由**衣摆被转体甩开**表达 |
| **气劲看起来像发光特效** | 气劲句没有介质 | 介质限定为：空气尾迹、衣袖、砂砾、落叶（脚步）、接触微压缩 |
| **全场尘土飞扬** | 规模过大 | 规模上限＝接触宽度 / 离刃一掌；扬尘只出现在脚下 |
| **落叶凭空飞起** | 没有施力来源 | 每处落叶动效都要有脚步作因：踩、踢、滑、碾 |
| **气劲抢了动作的戏** | 气劲写在身体受力之前 | 顺序固定：**先身体形变，后气劲** |
| 防守像软挡 | 用了被动动词 | 换硬防守动词（见第六节） |
| 防守方毫不费力 | 缺防守受力 | 补 `spine bows over the press`、`arms tremble under the load` |
| 防守方被压垮 | 只写受力没写坚持 | 补 `but he holds his ground` |
| 防守完重新开始 | 缺借力桥梁 | 补 `riding that pressure without pause: he uses the force he just absorbed to ...` |
